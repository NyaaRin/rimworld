﻿using HarmonyLib;
using RimWorld;
using Verse;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace SuperColonyBuffs.BioTech
{
    [StaticConstructorOnStartup]
    public static class HarmonyPatch
    {
        static HarmonyPatch()
        {
            var harmony = new Harmony("SuperColonyBuffs.BioTech");
            harmony.Patch(
            original: AccessTools.Method(typeof(FloatMenuMakerMap), "AddHumanlikeOrders"),
            postfix: new HarmonyMethod(typeof(HarmonyPatch), nameof(AddGeneMenuOptionsPostfix))
            );
        }

        private static void AddGeneMenuOptionsPostfix(Vector3 clickPos, Pawn pawn, List<FloatMenuOption> opts)
        {
            // Only show for humanlike pawns with genes
            if (pawn == null || !pawn.RaceProps.Humanlike || pawn.genes == null)
            {
                return;
            }

            // Add top-level "SuperColony Gene Injection" option
            FloatMenuOption geneMenuOption = new FloatMenuOption(
            "SuperColony Gene Injection",
            () =>
            {
                List<FloatMenuOption> subOptions = BioTechFloatMenu.GetBioTechFloatMenuOptions(pawn).ToList();
                FloatMenu subMenu = new FloatMenu(subOptions);
                Find.WindowStack.Add(subMenu);
            }
            );

            opts.Add(geneMenuOption);
        }
    }
}