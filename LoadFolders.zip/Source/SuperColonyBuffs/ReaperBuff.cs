﻿using System;
using System.Collections.Generic;
using System.Linq;
using Verse;
using RimWorld;
using HarmonyLib;
using SuperColonyBuffs.TechBurst; // For TechBurst utility
using SuperColonyBuffs.BioTech;   // For BioTech utility
using CombatExtended;
// using SuperColonyBuffs.StatEnhancer;
using static SuperColonyBuffs.BioTech.BioTechFloatMenu;
using UnityEngine;

namespace SuperColonyBuffs
{
    public static class ThingDefExtensions
    {
        public static bool IsArmor(this ThingDef def)
        {
            return def.IsApparel && (def.defName.Contains("Armor") || def.defName.Contains("Vest") || def.defName.Contains("Shield"));
        }
    }

    // Define the Hediff for the Reaper buff
    public class Hediff_ReaperBuff : HediffWithComps
    {
        public override void Tick()
        {
            base.Tick();
            Pawn pawn = this.pawn;
            if (pawn == null || pawn.Dead) return;

            // Max out all skills and prevent decay
            foreach (SkillRecord skill in pawn.skills.skills)
            {
                skill.Level = 20;
                skill.xpSinceLastLevel = skill.XpRequiredForLevelUp; // Prevents decay by keeping XP topped up
            }

            // Increase work speed (affects all work-related stats like construction, crafting, etc.)
            pawn.needs.mood.CurLevelPercentage = 1f; // Max mood for work speed bonuses
        }

        public override IEnumerable<Gizmo> GetGizmos()
        {
            foreach (var gizmo in base.GetGizmos())
            {
                yield return gizmo;
            }

            if (pawn != null && pawn.Faction == Faction.OfPlayer)
            {
                yield return new Command_Action
                {
                    defaultLabel = "Loadouts",
                    defaultDesc = "Manage loadouts",
                    icon = ContentFinder<Texture2D>.Get("UI/Commands/Assign"),
                    action = () =>
                    {
                        Find.WindowStack.Add(new LoadoutEditor());
                    }
                };
            }
        }
    }

    // Patch to add right-click options for pawns
    [HarmonyPatch(typeof(Pawn), "GetFloatMenuOptions")]
    public static class Patch_Pawn_GetFloatMenuOptions
    {
        static void Postfix(Pawn __instance, ref IEnumerable<FloatMenuOption> __result, Pawn selPawn)
        {
            List<FloatMenuOption> options = new List<FloatMenuOption>(__result);

            // Only allow the clicking pawn to be a colonist under player control
            if (selPawn == null || !selPawn.IsColonist || selPawn.Faction != Faction.OfPlayer) return;

            // "Capture" option for enemy pawns
            if (!__instance.IsColonist && __instance.Faction != Faction.OfPlayer && __instance.HostileTo(Faction.OfPlayer) && !__instance.Downed && !__instance.Dead)
            {
                options.Add(new FloatMenuOption("Capture", () =>
                {
                    // Down the pawn to make them capturable
                    BodyPartRecord brain = __instance.health.hediffSet.GetBrain();
                    if (brain != null)
                    {
                        DamageInfo damage = new DamageInfo(DamageDefOf.Blunt, 9999f, 0f, -1f, null, brain);
                        __instance.TakeDamage(damage);
                    }
                    else
                    {
                        // Fallback if brain is missing
                        DamageInfo damage = new DamageInfo(DamageDefOf.Blunt, 9999f);
                        __instance.TakeDamage(damage);
                    }
                    __instance.health.forceDowned = true;

                    // Instantly capture the pawn if downed
                    if (__instance.Downed)
                    {
                        __instance.SetFaction(Faction.OfPlayer, null);
                        __instance.guest.SetGuestStatus(Faction.OfPlayer, GuestStatus.Prisoner);
                        Messages.Message($"{__instance.Label} has been captured.", MessageTypeDefOf.PositiveEvent);
                    }
                    else
                    {
                        Messages.Message($"Failed to down {__instance.Label} for capture.", MessageTypeDefOf.NegativeEvent);
                    }
                }));
            }

            // Options for colonists (and optionally slaves/prisoners)
            bool canEquip = __instance.IsColonist ||
                           (__instance.IsPrisoner && ModSettings.applyToPrisoners) ||
                           (__instance.IsSlave && ModSettings.applyToSlaves);

            if (canEquip)
            {
                // "Buffs" menu
                options.Add(new FloatMenuOption("Buffs", () =>
                {
                    List<FloatMenuOption> buffOptions = new List<FloatMenuOption>();

                    // "Reaper" option
                    buffOptions.Add(new FloatMenuOption("Reaper", () =>
                    {
                        // Apply the Hediff_ReaperBuff hediff
                        Hediff reaperBuff = __instance.health.hediffSet.GetFirstHediffOfDef(DefDatabase<HediffDef>.GetNamed("Hediff_ReaperBuff", false));
                        if (reaperBuff == null)
                        {
                            reaperBuff = HediffMaker.MakeHediff(DefDatabase<HediffDef>.GetNamed("Hediff_ReaperBuff"), __instance);
                            __instance.health.AddHediff(reaperBuff);
                        }

                        // Add Industriousness trait
                        __instance.story.traits.GainTrait(new Trait(TraitDefOf.Industriousness, 2));
                        Messages.Message($"{__instance.Label} has been granted Reaper buffs.", MessageTypeDefOf.PositiveEvent);
                    }));

                    // "Cyborg" option
                    buffOptions.Add(new FloatMenuOption("Cyborg", () =>
                    {
                        var archotechParts = new Dictionary<BodyPartDef, HediffDef>
                        {
                            { BodyPartDefOf.Arm, DefDatabase<HediffDef>.GetNamed("ArchotechArm", false) },
                            { BodyPartDefOf.Leg, DefDatabase<HediffDef>.GetNamed("ArchotechLeg", false) },
                            { BodyPartDefOf.Eye, DefDatabase<HediffDef>.GetNamed("ArchotechEye", false) },
                            { DefDatabase<BodyPartDef>.GetNamed("Spine", false), DefDatabase<HediffDef>.GetNamed("ArchotechSpine", false) }
                        };

                        foreach (BodyPartRecord part in __instance.health.hediffSet.GetNotMissingParts())
                        {
                            if (archotechParts.TryGetValue(part.def, out HediffDef archotechHediff) && archotechHediff != null)
                            {
                                if (__instance.health.hediffSet.HasHediff(archotechHediff, part)) continue;
                                var existingHediffs = __instance.health.hediffSet.hediffs.Where(h => h.Part == part).ToList();
                                foreach (var hediff in existingHediffs)
                                {
                                    __instance.health.RemoveHediff(hediff);
                                }
                                Hediff addedPart = HediffMaker.MakeHediff(archotechHediff, __instance, part);
                                __instance.health.AddHediff(addedPart, part);
                            }
                        }
                        Messages.Message($"{__instance.Label} has been upgraded with Archotech parts.", MessageTypeDefOf.PositiveEvent);
                    }));

                    // "TechBurst" option
                    buffOptions.Add(new FloatMenuOption("TechBurst", () =>
                    {
                        TechBurstFloatMenu.ApplyTechBurst(__instance);
                    }));

                    Find.WindowStack.Add(new FloatMenu(buffOptions));
                }));

                // "SuperColony Gene Injection" menu
                options.Add(new FloatMenuOption("Izumi's Gene Injection", () =>
                {
                    List<FloatMenuOption> geneOptions = BioTechFloatMenu.GetBioTechFloatMenuOptions(__instance).ToList();
                    FloatMenu subMenu = new FloatMenu(geneOptions);
                    Find.WindowStack.Add(subMenu);
                }));

                // New option for Apply Max Psylink
                options.Add(new FloatMenuOption("Grant Max Psylink", () =>
                {
                    BioTechFloatMenu.ApplyMaxPsylink(__instance);
                }));

                // import for grass growing LOL






                // Infinite Ammo Toggle Menu
                options.Add(new FloatMenuOption("Toggle Infinite Ammo", () =>
                {
                    List<FloatMenuOption> ammoOptions = SuperColonyBuffs.InfiniteAmmoFloatMenu.GetInfiniteAmmoFloatMenuOptions(__instance).ToList();
                    FloatMenu subMenu = new FloatMenu(ammoOptions);
                    Find.WindowStack.Add(subMenu);
                }));

                // Add this snippet to your float menu generation code (e.g., in a Harmony patch)
                options.Add(new FloatMenuOption("Psionic Enhancements", () =>
                {
                    List<FloatMenuOption> psionicOptions = PsionicBuffs.GetPsionicFloatMenuOptions(__instance).ToList();
                    FloatMenu subMenu = new FloatMenu(psionicOptions);
                    Find.WindowStack.Add(subMenu);
                }));

                // Add this snippet to your float menu generation code (e.g., in a Harmony patch)
                options.Add(new FloatMenuOption("Enhance Stats", () =>
                {
                    List<FloatMenuOption> statOptions = StatEnhancer.GetEnhanceStatsFloatMenuOptions(__instance).ToList();
                    FloatMenu subMenu = new FloatMenu(statOptions);
                    Find.WindowStack.Add(subMenu);
                }));

                // "Loadouts" menu
                AddLoadoutsMenu(options, __instance);
            }

            __result = options;
        }

        private static void AddLoadoutsMenu(List<FloatMenuOption> options, Pawn pawn)
        {
            if (pawn == null || !pawn.Spawned || pawn.Dead)
            {
                options.Add(new FloatMenuOption("Loadouts (Pawn Invalid)", null));
                return;
            }

            var loadouts = LoadoutManager.GetLoadouts();
            if (loadouts == null || loadouts.Count == 0)
            {
                options.Add(new FloatMenuOption("Loadouts (None Available)", null));
                return;
            }

            var loadoutOptions = new List<FloatMenuOption>();
            
            // Add "Save Current Equipment" option
            loadoutOptions.Add(new FloatMenuOption("Save Current Equipment", () => {
                LoadoutEditor.OpenLoadoutEditorWithPawn(pawn);
            }));
            
            // Add "Edit Loadouts" option
            loadoutOptions.Add(new FloatMenuOption("Edit Loadouts", () => {
                LoadoutEditor.OpenLoadoutEditor();
            }));

            loadoutOptions.Add(new FloatMenuOption("----------------", null));

            // Add existing loadouts
            foreach (var loadout in loadouts)
            {
                loadoutOptions.Add(new FloatMenuOption($"Apply: {loadout.Name}", () => EquipLoadout(pawn, loadout)));
            }

            options.Add(new FloatMenuOption("Loadouts", () => Find.WindowStack.Add(new FloatMenu(loadoutOptions))));
        }

        private static void EquipLoadout(Pawn pawn, LoadoutData loadout)
        {
            if (pawn == null || loadout == null) return;

            // Clear current equipment and apparel
            if (pawn.equipment != null)
                {
                var eqList = pawn.equipment.AllEquipmentListForReading.ToList();
                foreach (var eq in eqList)
                    pawn.equipment.Remove(eq);
                }
            if (pawn.apparel != null)
            {
                var appList = pawn.apparel.WornApparel.ToList();
                foreach (var app in appList)
                    pawn.apparel.Remove(app);
            }

            // Apply helmet
                if (!string.IsNullOrEmpty(loadout.Helmet))
                {
                var def = DefDatabase<ThingDef>.GetNamed(loadout.Helmet, false);
                if (def != null)
                    {
                    ThingDef mat = GetDefaultMaterial(def);
                    var thing = ThingMaker.MakeThing(def, mat) as Apparel;
                    if (thing != null)
                        pawn.apparel.Wear(thing);
                    }
                }

            // Apply apparel
            foreach (var apparel in loadout.Apparel)
                {
                var def = DefDatabase<ThingDef>.GetNamed(apparel, false);
                if (def != null)
                    {
                    ThingDef mat = GetDefaultMaterial(def);
                    var thing = ThingMaker.MakeThing(def, mat) as Apparel;
                    if (thing != null)
                        pawn.apparel.Wear(thing);
                    }
                }

            // Apply primary weapon
                if (!string.IsNullOrEmpty(loadout.PrimaryWeapon))
                {
                var def = DefDatabase<ThingDef>.GetNamed(loadout.PrimaryWeapon, false);
                if (def != null)
                    {
                    var thing = ThingMaker.MakeThing(def) as ThingWithComps;
                    if (thing != null)
                        pawn.equipment.AddEquipment(thing);
                    }
                }

            // Apply secondary weapon
                if (!string.IsNullOrEmpty(loadout.SecondaryWeapon))
                {
                var def = DefDatabase<ThingDef>.GetNamed(loadout.SecondaryWeapon, false);
                if (def != null)
                    {
                    var thing = ThingMaker.MakeThing(def) as ThingWithComps;
                    if (thing != null)
                        pawn.equipment.AddEquipment(thing);
                    }
                }

            // Apply medkits
            foreach (var medkit in loadout.Medkits)
                {
                var def = DefDatabase<ThingDef>.GetNamed(medkit, false);
                if (def != null)
                    {
                    var thing = ThingMaker.MakeThing(def);
                    if (thing != null)
                        pawn.inventory.innerContainer.TryAdd(thing);
                    }
                }

            // Apply ammo
            foreach (var ammo in loadout.Ammo)
                {
                var def = DefDatabase<ThingDef>.GetNamed(ammo.Key, false);
                if (def != null)
                    {
                    var thing = ThingMaker.MakeThing(def);
                    if (thing != null)
                        {
                        thing.stackCount = ammo.Value;
                        pawn.inventory.innerContainer.TryAdd(thing);
                        }
                    }
                }

            // Apply extra items
            foreach (var extra in loadout.Extra)
                    {
                var def = DefDatabase<ThingDef>.GetNamed(extra, false);
                if (def != null)
                        {
                    var thing = ThingMaker.MakeThing(def);
                    if (thing != null)
                        pawn.inventory.innerContainer.TryAdd(thing);
                    }
                }

            Messages.Message($"Applied loadout '{loadout.Name}' to {pawn.Name.ToStringShort}", MessageTypeDefOf.PositiveEvent);
            }

        private static ThingDef GetDefaultMaterial(ThingDef def)
            {
            if (!def.MadeFromStuff) return null;
            
            var stuffCategories = def.stuffCategories;
            if (stuffCategories == null || stuffCategories.Count == 0) return null;

            // Try to use Cloth first
            var cloth = DefDatabase<ThingDef>.GetNamed("Cloth", false);
            if (cloth != null && cloth.stuffProps?.categories != null && 
                cloth.stuffProps.categories.Any(cat => stuffCategories.Contains(cat)))
            {
                return cloth;
            }

            // Try to use Steel next
            var steel = DefDatabase<ThingDef>.GetNamed("Steel", false);
            if (steel != null && steel.stuffProps?.categories != null && 
                steel.stuffProps.categories.Any(cat => stuffCategories.Contains(cat)))
            {
                return steel;
            }

            // Fall back to first valid material
            return DefDatabase<ThingDef>.AllDefsListForReading
                .FirstOrDefault(td => td.IsStuff && td.stuffProps?.categories != null && 
                td.stuffProps.categories.Any(cat => stuffCategories.Contains(cat)));
        }
    }
}