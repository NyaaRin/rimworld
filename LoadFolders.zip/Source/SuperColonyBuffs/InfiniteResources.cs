using Verse;
using RimWorld;
using System.Linq;
using HarmonyLib;
using System.Collections.Generic;

namespace SuperColonyBuffs
{
    public class GameComponent_InfiniteResources : GameComponent
    {
        public GameComponent_InfiniteResources(Game game) { }

        public override void GameComponentTick()
        {
            base.GameComponentTick();
            if (!ModSettings.infiniteResources) return;

            if (Find.TickManager.TicksGame % 60 == 0)
            {
                if (!ModSettings.preserveResourcesMode)
                {
                    foreach (Map map in Find.Maps)
                    {
                        if (map != null)
                        {
                            UpdateResources(map);
                        }
                    }
                }
            }
        }

        public static void UpdateResources(Map map)
        {
            if (map == null) return;

            foreach (Zone_Stockpile zone in map.zoneManager.AllZones.OfType<Zone_Stockpile>())
            {
                foreach (Thing thing in zone.AllContainedThings.Where(IsInfiniteResource))
                {
                    if (thing.def.stackLimit > 1)
                    {
                        thing.stackCount = thing.def.stackLimit;
                    }
                }
            }
        }

        // Helper method to determine if a thing should be considered for infinite resources
        private static bool IsInfiniteResource(Thing thing)
        {
            // Check if it's a resource.  Use a more reliable check.
            return (thing.def.category == ThingCategory.Item && thing.def.BaseMarketValue > 0f && thing.stackCount > 0 && !thing.IsForbidden(Faction.OfPlayer));
        }

        public override void StartedNewGame()
        {
            base.StartedNewGame();
            if (ModSettings.infiniteResources && !ModSettings.preserveResourcesMode)
            {
                foreach (Map map in Find.Maps)
                {
                    if (map != null)
                    {
                        UpdateResources(map);
                    }
                }
            }
        }

        public override void LoadedGame()
        {
            base.LoadedGame();
            if (ModSettings.infiniteResources && !ModSettings.preserveResourcesMode)
            {
                foreach (Map map in Find.Maps)
                {
                    if (map != null)
                    {
                        UpdateResources(map);
                    }
                }
            }
        }
    }

    // Patch to prevent resource consumption in preserve mode.  This patch is now more targeted.
    [HarmonyPatch(typeof(Thing), nameof(Thing.SplitOff))]
    public static class Patch_Thing_SplitOff
    {
        static bool Prefix(Thing __instance, int count, ref Thing __result)
        {
            if (ModSettings.infiniteResources && ModSettings.preserveResourcesMode && IsValidSplitOff(__instance))
            {
                Thing newThing = ThingMaker.MakeThing(__instance.def, __instance.Stuff);
                newThing.stackCount = count;
                __result = newThing;
                return false;
            }
            return true;
        }

        private static bool IsValidSplitOff(Thing thing)
        {
            // Only apply to resources, and not to things like equipped items or buildings.
            return thing.def.category == ThingCategory.Item && thing.def.BaseMarketValue > 0f && thing.stackCount > 0 && !thing.IsForbidden(Faction.OfPlayer);
        }
    }
}
