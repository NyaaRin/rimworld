using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Verse;
using RimWorld;

namespace SuperColonyBuffs
{
    public class LoadoutEditor : Window
    {
        private const float WindowWidth = 1100f;
        private const float WindowHeight = 700f;
        private const float LeftPanelWidth = 220f;
        private const float SectionSpacing = 18f;
        private const float ItemHeight = 32f;
        private const float ButtonWidth = 70f;
        private const float ButtonHeight = 28f;
        private const float SectionHeaderHeight = 28f;
        private const float SectionPadding = 8f;

        public override Vector2 InitialSize => new Vector2(WindowWidth, WindowHeight);
        private Vector2 scrollPosition = Vector2.zero;
        private Pawn previewPawn;
        private bool needsPreviewUpdate = true;
        private LoadoutData currentLoadout;
        private List<LoadoutData> allLoadouts;
        private string loadoutNameBuffer = "";
        private Pawn sourcePawn; // The pawn whose equipment we're viewing/editing
        // Cache for currently equipped items on the preview pawn
        private Dictionary<string, string> previewEquippedApparel = new Dictionary<string, string>(); // key: defName, value: material defName

        public static void OpenLoadoutEditor()
        {
            Find.WindowStack.Add(new LoadoutEditor());
        }

        public static void OpenLoadoutEditorWithPawn(Pawn pawn)
        {
            if (pawn != null)
            {
                Find.WindowStack.Add(new LoadoutEditor(pawn));
            }
            else
            {
                OpenLoadoutEditor();
            }
        }

        public static void ShowSavePawnGearMenu()
        {
            List<FloatMenuOption> options = new List<FloatMenuOption>();
            
            foreach (Pawn pawn in Find.CurrentMap.mapPawns.FreeColonists)
            {
                options.Add(new FloatMenuOption($"Save {pawn.Name.ToStringShort}'s Equipment", () => {
                    OpenLoadoutEditorWithPawn(pawn);
                }));
            }

            if (options.Any())
            {
                Find.WindowStack.Add(new FloatMenu(options));
            }
            else
            {
                Messages.Message("No colonists available to save equipment from.", MessageTypeDefOf.RejectInput);
            }
        }

        public LoadoutEditor(Pawn pawn = null)
        {
            forcePause = true;
            doCloseX = true;
            draggable = true;
            absorbInputAroundWindow = true;
            allLoadouts = LoadoutManager.GetLoadouts();
            currentLoadout = allLoadouts.FirstOrDefault() ?? new LoadoutData();
            loadoutNameBuffer = currentLoadout.Name ?? "";
            needsPreviewUpdate = true;
            sourcePawn = pawn;

            if (pawn != null)
            {
                // Create a new loadout from the pawn's equipment
                currentLoadout = new LoadoutData
                {
                    Name = $"{pawn.Name.ToStringShort}'s Equipment"
                };
                loadoutNameBuffer = currentLoadout.Name;

                // Save helmet
                var helmet = pawn.apparel?.WornApparel.FirstOrDefault(a => 
                    a.def.defName.ToLower().Contains("helmet") || 
                    a.def.label.ToLower().Contains("helmet"));
                if (helmet != null)
                {
                    currentLoadout.Helmet = helmet.def.defName;
                }

                // Save apparel
                currentLoadout.Apparel = pawn.apparel?.WornApparel
                    .Where(a => !a.def.defName.ToLower().Contains("helmet") && 
                               !a.def.label.ToLower().Contains("helmet"))
                    .Select(a => a.def.defName)
                    .ToList() ?? new List<string>();

                // Save primary weapon
                var primaryWeapon = pawn.equipment?.Primary;
                if (primaryWeapon != null)
                {
                    currentLoadout.PrimaryWeapon = primaryWeapon.def.defName;
                }

                // Save secondary weapon (if any)
                var secondaryWeapon = pawn.equipment?.AllEquipmentListForReading
                    .FirstOrDefault(e => e != primaryWeapon);
                if (secondaryWeapon != null)
                {
                    currentLoadout.SecondaryWeapon = secondaryWeapon.def.defName;
                }

                // Save medkits
                currentLoadout.Medkits = pawn.inventory?.innerContainer
                    .Where(t => t.def.thingCategories != null && 
                               t.def.thingCategories.Any(tc => 
                                   tc.defName.ToLower().Contains("medicine")))
                    .Select(t => t.def.defName)
                    .ToList() ?? new List<string>();

                // Save ammo
                currentLoadout.Ammo = pawn.inventory?.innerContainer
                    .Where(t => t.def.thingCategories != null && 
                               t.def.thingCategories.Any(tc => 
                                   tc.defName.ToLower().Contains("ammo")))
                    .GroupBy(t => t.def.defName)
                    .ToDictionary(g => g.Key, g => g.Sum(t => t.stackCount));

                // Save extra items
                currentLoadout.Extra = pawn.inventory?.innerContainer
                    .Where(t => !t.def.IsWeapon && 
                               !t.def.IsApparel && 
                               (t.def.thingCategories == null || 
                                !t.def.thingCategories.Any(tc => 
                                    tc.defName.ToLower().Contains("medicine") || 
                                    tc.defName.ToLower().Contains("ammo"))))
                    .Select(t => t.def.defName)
                    .ToList() ?? new List<string>();

                allLoadouts.Add(currentLoadout);
                LoadoutManager.SaveLoadouts();
            }
        }

        public override void DoWindowContents(Rect inRect)
        {
            // Left panel: Pawn preview
            Rect leftPanel = new Rect(inRect.x, inRect.y, LeftPanelWidth, inRect.height);
            Widgets.DrawBoxSolid(leftPanel, new Color(0.13f, 0.13f, 0.13f, 0.9f));
            if (previewPawn == null || needsPreviewUpdate)
            {
                Log.Message("[LoadoutEditor] Creating preview pawn...");
                CreatePreviewPawn();
                needsPreviewUpdate = false;
            }
            else
            {
                // Always update equipment to match current loadout
                UpdatePreviewPawnEquipment();
            }
            if (previewPawn != null)
            {
                Log.Message("[LoadoutEditor] Rendering preview pawn...");
                var previewRect = new Rect(leftPanel.x + 20f, leftPanel.y + 30f, 180f, 260f);
                RenderTexture portrait = PortraitsCache.Get(previewPawn, previewRect.size, Rot4.South);
                Widgets.DrawBox(previewRect);
                GUI.DrawTexture(previewRect, portrait);

                // Render primary and secondary weapon graphics below the pawn
                float weaponIconSize = 64f;
                float weaponSpacing = 10f;
                float weaponY = previewRect.yMax + 20f;
                if (!string.IsNullOrEmpty(currentLoadout.PrimaryWeapon))
                {
                    var def = DefDatabase<ThingDef>.GetNamed(currentLoadout.PrimaryWeapon, false);
                    if (def != null && def.uiIcon != null)
                    {
                        Rect iconRect = new Rect(previewRect.x + (previewRect.width - weaponIconSize) / 2, weaponY, weaponIconSize, weaponIconSize);
                        GUI.DrawTexture(iconRect, def.uiIcon);
                        Widgets.Label(new Rect(iconRect.x, iconRect.yMax, iconRect.width, 20f), "Primary");
                        weaponY += weaponIconSize + weaponSpacing + 20f;
                    }
                }
                if (!string.IsNullOrEmpty(currentLoadout.SecondaryWeapon))
                {
                    var def = DefDatabase<ThingDef>.GetNamed(currentLoadout.SecondaryWeapon, false);
                    if (def != null && def.uiIcon != null)
                    {
                        Rect iconRect = new Rect(previewRect.x + (previewRect.width - weaponIconSize) / 2, weaponY, weaponIconSize, weaponIconSize);
                        GUI.DrawTexture(iconRect, def.uiIcon);
                        Widgets.Label(new Rect(iconRect.x, iconRect.yMax, iconRect.width, 20f), "Secondary");
                    }
                }

                // Add button to apply loadout to source pawn if we have one
                if (sourcePawn != null)
                {
                    Rect applyButtonRect = new Rect(leftPanel.x + 20f, leftPanel.yMax - 40f, leftPanel.width - 40f, 30f);
                    if (Widgets.ButtonText(applyButtonRect, "Apply to " + sourcePawn.Name.ToStringShort))
                    {
                        ApplyLoadoutToPawn(sourcePawn);
                        Messages.Message($"Applied loadout to {sourcePawn.Name.ToStringShort}", MessageTypeDefOf.PositiveEvent);
                    }
                }
            }
            else
            {
                Log.Error("[LoadoutEditor] previewPawn is null in DoWindowContents!");
            }

            // Right panel: Loadout editing
            float rightPanelX = leftPanel.xMax + 10f;
            float rightPanelWidth = inRect.width - rightPanelX - 10f;
            Rect rightPanel = new Rect(rightPanelX, inRect.y, rightPanelWidth, inRect.height);
            Widgets.DrawBoxSolid(rightPanel, new Color(0.18f, 0.18f, 0.18f, 0.85f));

            float y = SectionPadding;
            float sectionWidth = rightPanel.width - 2 * SectionPadding;

            // Top: Loadout selector, rename, save, and delete
            float topBarY = rightPanel.y + y;
            float topBarX = rightPanel.x + SectionPadding;
            float topBarWidth = sectionWidth;
            float buttonSpacing = 10f;
            float nextX = topBarX;

            // Loadout selector
            if (Widgets.ButtonText(new Rect(nextX, topBarY, 110f, SectionHeaderHeight), currentLoadout.Name))
            {
                List<FloatMenuOption> options = new List<FloatMenuOption>();
                foreach (var l in allLoadouts)
                {
                    options.Add(new FloatMenuOption(l.Name, () => { currentLoadout = l; loadoutNameBuffer = l.Name; needsPreviewUpdate = true; }));
                }
                Find.WindowStack.Add(new FloatMenu(options));
            }
            nextX += 110f + buttonSpacing;

            // Rename label and field
            Widgets.Label(new Rect(nextX, topBarY, 60f, SectionHeaderHeight), "Rename:");
            nextX += 60f;
            loadoutNameBuffer = Widgets.TextField(new Rect(nextX, topBarY, 140f, SectionHeaderHeight), loadoutNameBuffer, 30);
            if (currentLoadout.Name != loadoutNameBuffer)
            {
                currentLoadout.Name = loadoutNameBuffer;
                LoadoutManager.SaveLoadouts();
                UpdatePreviewPawnEquipment();
            }
            nextX += 140f + buttonSpacing;

            // New Loadout button
            if (Widgets.ButtonText(new Rect(nextX, topBarY, 110f, SectionHeaderHeight), "New Loadout"))
            {
                var newLoadout = new LoadoutData { Name = "New Loadout" };
                allLoadouts.Add(newLoadout);
                currentLoadout = newLoadout;
                loadoutNameBuffer = newLoadout.Name;
                needsPreviewUpdate = true;
                LoadoutManager.SaveLoadouts();
                CreatePreviewPawn();
            }
            nextX += 110f + buttonSpacing;

            // Delete Loadout button
            if (allLoadouts.Count > 1 && Widgets.ButtonText(new Rect(nextX, topBarY, 110f, SectionHeaderHeight), "Delete Loadout"))
            {
                allLoadouts.Remove(currentLoadout);
                currentLoadout = allLoadouts.First();
                loadoutNameBuffer = currentLoadout.Name;
                needsPreviewUpdate = true;
                LoadoutManager.SaveLoadouts();
                CreatePreviewPawn();
            }
            nextX += 110f + buttonSpacing;

            // Save button
            if (Widgets.ButtonText(new Rect(nextX, topBarY, 90f, SectionHeaderHeight), "Save"))
            {
                LoadoutManager.SaveLoadouts();
                Messages.Message("Loadouts saved!", MessageTypeDefOf.PositiveEvent);
            }

            y += SectionHeaderHeight + SectionSpacing;

            // --- DYNAMIC SCROLL AREA SIZE CALCULATION ---
            // Calculate max width and total height needed for all sections
            float maxSectionWidth = sectionWidth;
            float totalSectionHeight = 0f;
            // Helper to measure text width
            float MeasureTextWidth(string text, GameFont font)
            {
                Text.Font = font;
                float w = Text.CalcSize(text).x;
                Text.Font = GameFont.Small;
                return w;
            }
            // Helmet
            maxSectionWidth = Mathf.Max(maxSectionWidth, MeasureTextWidth("Helmet", GameFont.Medium) + 300f);
            totalSectionHeight += SectionHeaderHeight + ItemHeight + SectionPadding * 2 + SectionSpacing;
            // Apparel
            float apparelW = MeasureTextWidth("Apparel", GameFont.Medium) + 300f;
            foreach (var a in currentLoadout.Apparel) apparelW = Mathf.Max(apparelW, MeasureTextWidth(a, GameFont.Small) + 200f);
            maxSectionWidth = Mathf.Max(maxSectionWidth, apparelW);
            totalSectionHeight += SectionHeaderHeight + Math.Max(1, currentLoadout.Apparel.Count) * (ItemHeight + 2f) + ButtonHeight + SectionPadding * 2 + SectionSpacing;
            // Primary Weapon
            maxSectionWidth = Mathf.Max(maxSectionWidth, MeasureTextWidth("Primary Weapon", GameFont.Medium) + 300f);
            totalSectionHeight += SectionHeaderHeight + ItemHeight + SectionPadding * 2 + SectionSpacing;
            // Secondary Weapon
            maxSectionWidth = Mathf.Max(maxSectionWidth, MeasureTextWidth("Secondary Weapon", GameFont.Medium) + 300f);
            totalSectionHeight += SectionHeaderHeight + ItemHeight + SectionPadding * 2 + SectionSpacing;
            // Medkits
            float medkitW = MeasureTextWidth("Medkits", GameFont.Medium) + 300f;
            foreach (var m in currentLoadout.Medkits) medkitW = Mathf.Max(medkitW, MeasureTextWidth(m, GameFont.Small) + 200f);
            maxSectionWidth = Mathf.Max(maxSectionWidth, medkitW);
            totalSectionHeight += SectionHeaderHeight + Math.Max(1, currentLoadout.Medkits.Count) * (ItemHeight + 2f) + ButtonHeight + SectionPadding * 2 + SectionSpacing;
            // Extra
            float extraW = MeasureTextWidth("Extra", GameFont.Medium) + 300f;
            foreach (var e in currentLoadout.Extra) extraW = Mathf.Max(extraW, MeasureTextWidth(e, GameFont.Small) + 200f);
            maxSectionWidth = Mathf.Max(maxSectionWidth, extraW);
            totalSectionHeight += SectionHeaderHeight + Math.Max(1, currentLoadout.Extra.Count) * (ItemHeight + 2f) + ButtonHeight + SectionPadding * 2 + SectionSpacing;
            // Ammo
            float ammoW = MeasureTextWidth("Ammo", GameFont.Medium) + 300f;
            foreach (var k in currentLoadout.Ammo.Keys) ammoW = Mathf.Max(ammoW, MeasureTextWidth(k + ": " + currentLoadout.Ammo[k], GameFont.Small) + 200f);
            maxSectionWidth = Mathf.Max(maxSectionWidth, ammoW);
            totalSectionHeight += SectionHeaderHeight + Math.Max(1, currentLoadout.Ammo.Count) * (ItemHeight + 2f) + ButtonHeight + SectionPadding * 2 + SectionSpacing;

            // Begin scrollable area for all sections
            float scrollableHeight = rightPanel.height - y - 20f;
            float scrollViewWidth = Mathf.Max(sectionWidth, maxSectionWidth);
            Rect scrollOutRect = new Rect(rightPanel.x + SectionPadding, rightPanel.y + y, sectionWidth, scrollableHeight);
            Rect scrollViewRect = new Rect(0, 0, scrollViewWidth, totalSectionHeight + 40f);
            Widgets.BeginScrollView(scrollOutRect, ref scrollPosition, scrollViewRect, true);
            float sy = 0f;

            // Ensure Ammo and Extra are always initialized
            if (currentLoadout.Ammo == null) currentLoadout.Ammo = new Dictionary<string, int>();
            if (currentLoadout.Extra == null) currentLoadout.Extra = new List<string>();

            // Section: Helmet
            DrawItemSection(scrollViewRect, ref sy, "Helmet", currentLoadout.Helmet, (defName, matDefName) => {
                currentLoadout.Helmet = defName;
                if (!string.IsNullOrEmpty(matDefName)) currentLoadout.ItemMaterials[defName] = matDefName;
                else currentLoadout.ItemMaterials.Remove(defName);
            }, () => { currentLoadout.Helmet = null; }, single: true);
            sy += SectionSpacing;
            // Section: Apparel
            DrawListSection(scrollViewRect, ref sy, "Apparel", currentLoadout.Apparel, (defName, matDefName) => {
                currentLoadout.Apparel.Add(defName);
                if (!string.IsNullOrEmpty(matDefName)) currentLoadout.ItemMaterials[defName] = matDefName;
            }, (idx) => {
                var defName = currentLoadout.Apparel[idx];
                currentLoadout.Apparel.RemoveAt(idx);
                currentLoadout.ItemMaterials.Remove(defName);
            });
            sy += SectionSpacing;
            // Section: Primary Weapon
            DrawItemSection(scrollViewRect, ref sy, "Primary Weapon", currentLoadout.PrimaryWeapon, (defName, matDefName) => {
                currentLoadout.PrimaryWeapon = defName;
                if (!string.IsNullOrEmpty(matDefName)) currentLoadout.ItemMaterials[defName] = matDefName;
                else currentLoadout.ItemMaterials.Remove(defName);
            }, () => { currentLoadout.PrimaryWeapon = null; }, single: true);
            sy += SectionSpacing;
            // Section: Secondary Weapon
            DrawItemSection(scrollViewRect, ref sy, "Secondary Weapon", currentLoadout.SecondaryWeapon, (defName, matDefName) => {
                currentLoadout.SecondaryWeapon = defName;
                if (!string.IsNullOrEmpty(matDefName)) currentLoadout.ItemMaterials[defName] = matDefName;
                else currentLoadout.ItemMaterials.Remove(defName);
            }, () => { currentLoadout.SecondaryWeapon = null; }, single: true);
            sy += SectionSpacing;
            // Section: Medkits
            DrawListSection(scrollViewRect, ref sy, "Medkits", currentLoadout.Medkits, (defName, matDefName) => {
                currentLoadout.Medkits.Add(defName);
                if (!string.IsNullOrEmpty(matDefName)) currentLoadout.ItemMaterials[defName] = matDefName;
            }, (idx) => {
                var defName = currentLoadout.Medkits[idx];
                currentLoadout.Medkits.RemoveAt(idx);
                currentLoadout.ItemMaterials.Remove(defName);
            });
            sy += SectionSpacing;
            // Section: Extra
            DrawListSection(scrollViewRect, ref sy, "Extra", currentLoadout.Extra, (defName, matDefName) => {
                currentLoadout.Extra.Add(defName);
                if (!string.IsNullOrEmpty(matDefName)) currentLoadout.ItemMaterials[defName] = matDefName;
            }, (idx) => {
                var defName = currentLoadout.Extra[idx];
                currentLoadout.Extra.RemoveAt(idx);
                currentLoadout.ItemMaterials.Remove(defName);
            });
            sy += SectionSpacing;
            // Section: Ammo
            DrawAmmoSection(scrollViewRect, ref sy, currentLoadout);
            sy += SectionSpacing;

            Widgets.EndScrollView();
        }

        private float GetTotalSectionHeight(LoadoutData loadout)
        {
            // Estimate total height for all sections
            int apparelCount = loadout.Apparel?.Count ?? 0;
            int medkitCount = loadout.Medkits?.Count ?? 0;
            int extraCount = loadout.Extra?.Count ?? 0;
            int ammoCount = loadout.Ammo?.Count ?? 0;
            return (SectionHeaderHeight + ItemHeight + SectionSpacing) * 6 + (apparelCount + medkitCount + extraCount + ammoCount) * (ItemHeight + 2f) + 100f;
        }

        private void DrawItemSection(Rect inRect, ref float y, string label, string value, Action<string, string> onSelect, Action onRemove, bool single = false)
        {
            float rightPadding = 60f;
            Rect sectionRect = new Rect(inRect.x, inRect.y + y, inRect.width - rightPadding, SectionHeaderHeight + ItemHeight + SectionPadding * 2);
            Widgets.DrawBoxSolid(sectionRect, new Color(0.22f, 0.22f, 0.22f, 0.9f));
            Rect labelRect = new Rect(sectionRect.x + SectionPadding, sectionRect.y + SectionPadding, sectionRect.width - 2 * SectionPadding, SectionHeaderHeight);
            Text.Font = GameFont.Medium;
            Widgets.Label(labelRect, label);
            Text.Font = GameFont.Small;
            Rect itemRect = new Rect(labelRect.x, labelRect.yMax + 2f, labelRect.width - ButtonWidth - 10f, ItemHeight);
            string display = (value ?? "None");
            if (display.Length > 32) display = display.Substring(0, 29) + "...";
            Widgets.Label(itemRect, display);
            // Show material if present
            string matDef = null;
            if (!string.IsNullOrEmpty(value) && currentLoadout.ItemMaterials.TryGetValue(value, out matDef) && !string.IsNullOrEmpty(matDef))
            {
                var matThing = DefDatabase<ThingDef>.GetNamed(matDef, false);
                if (matThing != null)
                {
                    Rect matRect = new Rect(itemRect.xMax + 6f, itemRect.y, 100f, ItemHeight);
                    Widgets.Label(matRect, $"[{matThing.LabelCap}]");
                    if (Widgets.ButtonText(new Rect(matRect.xMax + 6f, itemRect.y, ButtonWidth, ButtonHeight), "Change Mat"))
                    {
                        var def = DefDatabase<ThingDef>.GetNamed(value, false);
                        if (def != null && def.MadeFromStuff)
                        {
                            ShowMaterialSelector(def, (mat) => { onSelect(def.defName, mat.defName); LoadoutManager.SaveLoadouts(); UpdatePreviewPawnEquipment(); });
                        }
                    }
                }
            }
            if (!string.IsNullOrEmpty(value) && Mouse.IsOver(itemRect))
                TooltipHandler.TipRegion(itemRect, value);
            if (Widgets.ButtonText(new Rect(itemRect.xMax + 6f, itemRect.y, ButtonWidth, ButtonHeight), "Select"))
            {
                ShowThingDefSelector(label, (defName, matDefName) => { onSelect(defName, matDefName); LoadoutManager.SaveLoadouts(); UpdatePreviewPawnEquipment(); });
            }
            if (!string.IsNullOrEmpty(value) && Widgets.ButtonText(new Rect(itemRect.xMax + ButtonWidth + 12f, itemRect.y, ButtonWidth, ButtonHeight), "Remove"))
            {
                onRemove();
                LoadoutManager.SaveLoadouts();
                UpdatePreviewPawnEquipment();
            }
            y += sectionRect.height;
        }

        private void DrawListSection(Rect inRect, ref float y, string label, List<string> values, Action<string, string> onAdd, Action<int> onRemove)
        {
            float rightPadding = 60f;
            Rect sectionRect = new Rect(inRect.x, inRect.y + y, inRect.width - rightPadding, SectionHeaderHeight + Math.Max(1, values.Count) * (ItemHeight + 2f) + ButtonHeight + SectionPadding * 2);
            Widgets.DrawBoxSolid(sectionRect, new Color(0.22f, 0.22f, 0.22f, 0.9f));
            Rect labelRect = new Rect(sectionRect.x + SectionPadding, sectionRect.y + SectionPadding, sectionRect.width - 2 * SectionPadding, SectionHeaderHeight);
            Text.Font = GameFont.Medium;
            Widgets.Label(labelRect, label);
            Text.Font = GameFont.Small;
            float itemY = labelRect.yMax + 2f;
            for (int i = 0; i < values.Count; i++)
            {
                var val = values[i];
                Rect itemRect = new Rect(labelRect.x, itemY, labelRect.width - ButtonWidth - 10f, ItemHeight);
                string display = val.Length > 32 ? val.Substring(0, 29) + "..." : val;
                Widgets.Label(itemRect, display);
                // Show material if present
                string matDef = null;
                if (!string.IsNullOrEmpty(val) && currentLoadout.ItemMaterials.TryGetValue(val, out matDef) && !string.IsNullOrEmpty(matDef))
                {
                    var matThing = DefDatabase<ThingDef>.GetNamed(matDef, false);
                    if (matThing != null)
                    {
                        Rect matRect = new Rect(itemRect.xMax + 6f, itemY, 100f, ItemHeight);
                        Widgets.Label(matRect, $"[{matThing.LabelCap}]");
                        if (Widgets.ButtonText(new Rect(matRect.xMax + 6f, itemY, ButtonWidth, ButtonHeight), "Change Mat"))
                        {
                            var def = DefDatabase<ThingDef>.GetNamed(val, false);
                            if (def != null && def.MadeFromStuff)
                            {
                                ShowMaterialSelector(def, (mat) => { currentLoadout.ItemMaterials[val] = mat.defName; LoadoutManager.SaveLoadouts(); UpdatePreviewPawnEquipment(); });
                            }
                        }
                    }
                }
                if (Mouse.IsOver(itemRect))
                    TooltipHandler.TipRegion(itemRect, val);
                if (Widgets.ButtonText(new Rect(itemRect.xMax + 6f, itemY, ButtonWidth, ButtonHeight), "Remove"))
                {
                    onRemove(i);
                    LoadoutManager.SaveLoadouts();
                    UpdatePreviewPawnEquipment();
                    return; // Prevent collection modification during enumeration
                }
                itemY += ItemHeight + 2f;
            }
            if (Widgets.ButtonText(new Rect(labelRect.x, itemY, ButtonWidth, ButtonHeight), "Add"))
            {
                ShowThingDefSelector(label, (defName, matDefName) => { onAdd(defName, matDefName); LoadoutManager.SaveLoadouts(); UpdatePreviewPawnEquipment(); });
            }
            y += sectionRect.height;
        }

        private void DrawAmmoSection(Rect inRect, ref float y, LoadoutData loadout)
        {
            float rightPadding = 60f;
            if (loadout.Ammo == null) loadout.Ammo = new Dictionary<string, int>();
            Rect sectionRect = new Rect(inRect.x, inRect.y + y, inRect.width - rightPadding, SectionHeaderHeight + Math.Max(1, loadout.Ammo.Count) * (ItemHeight + 2f) + ButtonHeight + SectionPadding * 2);
            Widgets.DrawBoxSolid(sectionRect, new Color(0.22f, 0.22f, 0.22f, 0.9f));
            Rect labelRect = new Rect(sectionRect.x + SectionPadding, sectionRect.y + SectionPadding, sectionRect.width - 2 * SectionPadding, SectionHeaderHeight);
            Widgets.Label(labelRect, "Ammo");
            float itemY = labelRect.yMax + 2f;
            var keys = loadout.Ammo.Keys.ToList();
            for (int i = 0; i < keys.Count; i++)
            {
                var key = keys[i];
                var val = loadout.Ammo[key];
                Rect itemRect = new Rect(labelRect.x, itemY, labelRect.width - ButtonWidth * 2 - 20f, ItemHeight);
                Text.WordWrap = true;
                Widgets.Label(itemRect, $"{key}: {val}");
                Text.WordWrap = false;
                if (Widgets.ButtonText(new Rect(itemRect.xMax + 6f, itemY, ButtonWidth, ButtonHeight), "Edit"))
                {
                    Find.WindowStack.Add(new Dialog_EditValue(key, val, (newVal) => { loadout.Ammo[key] = newVal; LoadoutManager.SaveLoadouts(); UpdatePreviewPawnEquipment(); }));
                }
                if (Widgets.ButtonText(new Rect(itemRect.xMax + ButtonWidth + 12f, itemY, ButtonWidth, ButtonHeight), "Remove"))
                {
                    loadout.Ammo.Remove(key);
                    LoadoutManager.SaveLoadouts();
                    UpdatePreviewPawnEquipment();
                    return;
                }
                itemY += ItemHeight + 2f;
            }
            if (Widgets.ButtonText(new Rect(labelRect.x, itemY, ButtonWidth, ButtonHeight), "Add"))
            {
                ShowThingDefSelector("Ammo", (defName, matDefName) => {
                    loadout.Ammo[defName] = 400; // Always set to 400, even if it already exists
                    LoadoutManager.SaveLoadouts();
                    UpdatePreviewPawnEquipment();
                });
            }
            y += sectionRect.height;
        }

        private void ShowMaterialSelector(ThingDef itemDef, Action<ThingDef> onSelect)
        {
            var stuffCategories = itemDef.stuffCategories;
            var validMaterials = DefDatabase<ThingDef>.AllDefsListForReading
                .Where(td => td.IsStuff && td.stuffProps?.categories != null &&
                    td.stuffProps.categories.Any(cat => stuffCategories.Contains(cat)))
                .OrderBy(td => td.label)
                .ToList();
            List<FloatMenuOption> options = new List<FloatMenuOption>();
            foreach (var mat in validMaterials)
            {
                options.Add(new FloatMenuOption(mat.LabelCap, () => onSelect(mat)));
            }
            Find.WindowStack.Add(new FloatMenu(options));
        }

        private void ShowThingDefSelector(string category, Action<string, string> onSelect)
        {
            List<FloatMenuOption> options = new List<FloatMenuOption>();
            IEnumerable<ThingDef> defs = DefDatabase<ThingDef>.AllDefsListForReading;
            if (category == "Helmet")
                defs = defs.Where(d => d.IsApparel && (
                    d.defName.ToLower().Contains("helmet") ||
                    d.label.ToLower().Contains("helmet") ||
                    d.defName.ToLower().Contains("hat") ||
                    d.label.ToLower().Contains("hat") ||
                    d.defName.ToLower().Contains("hood") ||
                    d.label.ToLower().Contains("hood")));
            else if (category == "Apparel")
                defs = defs.Where(d => d.IsApparel);
            else if (category.Contains("Weapon"))
                defs = defs.Where(d => d.IsWeapon);
            else if (category == "Medkits")
                defs = defs.Where(d => d.thingCategories != null && d.thingCategories.Any(tc => tc.defName.ToLower().Contains("medicine")));
            else if (category == "Extra")
                defs = defs.Where(d => !d.IsWeapon && !d.IsApparel && d.category == ThingCategory.Item);
            else if (category == "Ammo")
                defs = defs.Where(d => d.thingCategories != null && d.thingCategories.Any(tc => tc.defName.ToLower().Contains("ammo")));
            foreach (var def in defs.OrderBy(d => d.label))
            {
                if (def.MadeFromStuff)
                {
                    options.Add(new FloatMenuOption(def.label + "...", () =>
                    {
                        ShowMaterialSelector(def, (mat) => onSelect(def.defName, mat.defName));
                    }));
                }
                else
                {
                    options.Add(new FloatMenuOption(def.label, () => onSelect(def.defName, null)));
                }
            }
            Find.WindowStack.Add(new FloatMenu(options));
        }

        private void CreatePreviewPawn()
        {
            Log.Message("[LoadoutEditor] Entering CreatePreviewPawn...");
            if (previewPawn != null)
            {
                previewPawn.Destroy();
                previewPawn = null;
            }
            PawnKindDef kindDef = PawnKindDefOf.Colonist;
            Faction faction = Faction.OfPlayer;
            previewPawn = PawnGenerator.GeneratePawn(new PawnGenerationRequest(kindDef, faction, PawnGenerationContext.NonPlayer, -1, forceGenerateNewPawn: true));
            if (previewPawn == null)
                Log.Error("[LoadoutEditor] Preview pawn is null after generation!");
            else
                Log.Message("[LoadoutEditor] Preview pawn created: " + previewPawn.ToString());
            previewPawn.Name = new NameSingle("Preview");
            previewPawn.gender = Gender.Female;
            
            // Clear equipment and apparel safely (do not drop)
            if (previewPawn.equipment != null)
            {
                var eqList = previewPawn.equipment.AllEquipmentListForReading.ToList();
                foreach (var eq in eqList)
                    previewPawn.equipment.Remove(eq);
            }
            if (previewPawn.apparel != null)
            {
                var appList = previewPawn.apparel.WornApparel.ToList();
                foreach (var app in appList)
                    previewPawn.apparel.Remove(app);
            }

            // Equip preview pawn with current loadout
            if (currentLoadout != null)
            {
                Log.Message($"[LoadoutEditor] Loading loadout: {currentLoadout.Name}");
                
                // Helmet
                if (!string.IsNullOrEmpty(currentLoadout.Helmet))
                {
                    var def = DefDatabase<ThingDef>.GetNamed(currentLoadout.Helmet, false);
                    if (def != null)
                    {
                        string matDefName = null;
                        currentLoadout.ItemMaterials.TryGetValue(def.defName, out matDefName);
                        if (!string.IsNullOrEmpty(matDefName))
                        {
                            var mat = DefDatabase<ThingDef>.GetNamed(matDefName, false);
                            var thing = ThingMaker.MakeThing(def, mat) as Apparel;
                            if (thing != null)
                            {
                                try
                                {
                                    if (previewPawn.apparel.CanWearWithoutDroppingAnything(thing.def))
                                    {
                                        previewPawn.apparel.Wear(thing);
                                        Log.Message($"[LoadoutEditor] Equipped helmet: {def.defName}");
                                    }
                                    else
                                    {
                                        Log.Error($"[LoadoutEditor] Cannot wear helmet {def.defName} - incompatible with current apparel");
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Log.Error($"[LoadoutEditor] Failed to wear helmet {def.defName}: {ex.Message}");
                                }
                            }
                            else
                                Log.Error($"[LoadoutEditor] Failed to create helmet: {def.defName}");
                        }
                        else
                        {
                            var mat = GetDefaultMaterial(def);
                            var thing = ThingMaker.MakeThing(def, mat) as Apparel;
                            if (thing != null)
                            {
                                try
                                {
                                    if (previewPawn.apparel.CanWearWithoutDroppingAnything(thing.def))
                                    {
                                        previewPawn.apparel.Wear(thing);
                                        Log.Message($"[LoadoutEditor] Equipped helmet: {def.defName}");
                                    }
                                    else
                                    {
                                        Log.Error($"[LoadoutEditor] Cannot wear helmet {def.defName} - incompatible with current apparel");
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Log.Error($"[LoadoutEditor] Failed to wear helmet {def.defName}: {ex.Message}");
                                }
                            }
                        }
                    }
                    else
                        Log.Error($"[LoadoutEditor] Helmet def not found: {currentLoadout.Helmet}");
                }

                // Apparel
                if (currentLoadout.Apparel != null)
                {
                    Log.Message($"[LoadoutEditor] Loading {currentLoadout.Apparel.Count} apparel items");
                    // Sort apparel by layer to ensure proper wearing order
                    var sortedApparel = currentLoadout.Apparel
                        .Select(defName => DefDatabase<ThingDef>.GetNamed(defName, false))
                        .Where(def => def != null && def.IsApparel)
                        .OrderBy(def => def.apparel?.layers?.FirstOrDefault()?.drawOrder ?? 0)
                        .ToList();

                    foreach (var def in sortedApparel)
                    {
                        if (def == null) continue;

                        string matDefName = null;
                        currentLoadout.ItemMaterials.TryGetValue(def.defName, out matDefName);
                        if (!string.IsNullOrEmpty(matDefName))
                        {
                            var mat = DefDatabase<ThingDef>.GetNamed(matDefName, false);
                            var thing = ThingMaker.MakeThing(def, mat) as Apparel;
                            if (thing != null)
                            {
                                try
                                {
                                    if (previewPawn.apparel.CanWearWithoutDroppingAnything(thing.def))
                                    {
                                        previewPawn.apparel.Wear(thing);
                                        Log.Message($"[LoadoutEditor] Equipped apparel: {def.defName}");
                                    }
                                    else
                                    {
                                        Log.Error($"[LoadoutEditor] Cannot wear apparel {def.defName} - incompatible with current apparel");
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Log.Error($"[LoadoutEditor] Failed to wear apparel {def.defName}: {ex.Message}");
                                }
                            }
                            else
                                Log.Error($"[LoadoutEditor] Failed to create apparel: {def.defName}");
                        }
                        else
                        {
                            var mat = GetDefaultMaterial(def);
                            var thing = ThingMaker.MakeThing(def, mat) as Apparel;
                            if (thing != null)
                            {
                                try
                                {
                                    if (previewPawn.apparel.CanWearWithoutDroppingAnything(thing.def))
                                    {
                                        previewPawn.apparel.Wear(thing);
                                        Log.Message($"[LoadoutEditor] Equipped apparel: {def.defName}");
                                    }
                                    else
                                    {
                                        Log.Error($"[LoadoutEditor] Cannot wear apparel {def.defName} - incompatible with current apparel");
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Log.Error($"[LoadoutEditor] Failed to wear apparel {def.defName}: {ex.Message}");
                                }
                            }
                        }
                    }
                }
                else
                {
                    Log.Warning("[LoadoutEditor] Apparel list is null");
                }

                // Primary weapon
                if (!string.IsNullOrEmpty(currentLoadout.PrimaryWeapon))
                {
                    var def = DefDatabase<ThingDef>.GetNamed(currentLoadout.PrimaryWeapon, false);
                    if (def != null)
                    {
                        var thing = ThingMaker.MakeThing(def) as ThingWithComps;
                        if (thing != null)
                        {
                            previewPawn.equipment.AddEquipment(thing);
                            Log.Message($"[LoadoutEditor] Equipped primary weapon: {def.defName}");
                        }
                        else
                            Log.Error($"[LoadoutEditor] Failed to create primary weapon: {def.defName}");
                    }
                    else
                        Log.Error($"[LoadoutEditor] Primary weapon def not found: {currentLoadout.PrimaryWeapon}");
                }
            }
            else
            {
                Log.Error("[LoadoutEditor] Current loadout is null");
            }
        }

        private ThingDef GetDefaultMaterial(ThingDef def)
        {
            if (!def.MadeFromStuff) return null;
            
            var stuffCategories = def.stuffCategories;
            if (stuffCategories == null || stuffCategories.Count == 0) return null;

            // Try to use Cloth first for clothing
            if (def.IsApparel && def.apparel?.layers?.Any(l => l == ApparelLayerDefOf.OnSkin || l == ApparelLayerDefOf.Middle) == true)
            {
                var cloth = DefDatabase<ThingDef>.GetNamed("Cloth", false);
                if (cloth != null && cloth.stuffProps?.categories != null && 
                    cloth.stuffProps.categories.Any(cat => stuffCategories.Contains(cat)))
                {
                    return cloth;
                }
            }

            // Try to use Steel for armor and outer layers
            if (def.IsApparel && def.apparel?.layers?.Any(l => l == ApparelLayerDefOf.Overhead || l == ApparelLayerDefOf.Shell) == true)
            {
                var steel = DefDatabase<ThingDef>.GetNamed("Steel", false);
                if (steel != null && steel.stuffProps?.categories != null && 
                    steel.stuffProps.categories.Any(cat => stuffCategories.Contains(cat)))
                {
                    return steel;
                }
            }

            // Fall back to first valid material
            return DefDatabase<ThingDef>.AllDefsListForReading
                .FirstOrDefault(td => td.IsStuff && td.stuffProps?.categories != null && 
                td.stuffProps.categories.Any(cat => stuffCategories.Contains(cat)));
        }

        private void UpdatePreviewPawnEquipment()
        {
            if (previewPawn == null)
            {
                Log.Error("[LoadoutEditor] Preview pawn is null in UpdatePreviewPawnEquipment");
                return;
            }

            // Build target apparel/materials from currentLoadout
            var targetApparel = new List<(string defName, string matDefName)>();
            if (!string.IsNullOrEmpty(currentLoadout.Helmet))
            {
                string matDef = null;
                currentLoadout.ItemMaterials.TryGetValue(currentLoadout.Helmet, out matDef);
                targetApparel.Add((currentLoadout.Helmet, matDef));
            }
            foreach (var apparel in currentLoadout.Apparel)
            {
                string matDef = null;
                currentLoadout.ItemMaterials.TryGetValue(apparel, out matDef);
                targetApparel.Add((apparel, matDef));
            }

            // Get currently equipped
            var currentlyEquipped = previewPawn.apparel?.WornApparel
                .Select(a => (a.def.defName, a.Stuff?.defName ?? ""))
                .ToList() ?? new List<(string, string)>();

            // Only update if different
            bool needsUpdate = false;
            if (currentlyEquipped.Count != targetApparel.Count)
                needsUpdate = true;
            else
            {
                for (int i = 0; i < currentlyEquipped.Count; i++)
                {
                    if (currentlyEquipped[i].defName != targetApparel[i].defName || currentlyEquipped[i].Item2 != (targetApparel[i].matDefName ?? ""))
                    {
                        needsUpdate = true;
                        break;
                    }
                }
            }

            if (!needsUpdate)
            {
                Log.Message("[LoadoutEditor] Preview pawn apparel is up to date, skipping update.");
                return;
            }

            Log.Message("[LoadoutEditor] Updating preview pawn apparel.");
            // Clear current equipment and apparel safely (do not drop)
            if (previewPawn.equipment != null)
            {
                var eqList = previewPawn.equipment.AllEquipmentListForReading.ToList();
                foreach (var eq in eqList)
                    previewPawn.equipment.Remove(eq);
            }
            if (previewPawn.apparel != null)
            {
                var appList = previewPawn.apparel.WornApparel.ToList();
                foreach (var app in appList)
                    previewPawn.apparel.Remove(app);
            }

            // Equip preview pawn with current loadout
            if (currentLoadout != null)
            {
                Log.Message($"[LoadoutEditor] Updating equipment for loadout: {currentLoadout.Name}");
                foreach (var (defName, matDefName) in targetApparel)
                {
                    var def = DefDatabase<ThingDef>.GetNamed(defName, false);
                    if (def != null)
                    {
                        ThingDef mat = null;
                        if (!string.IsNullOrEmpty(matDefName))
                            mat = DefDatabase<ThingDef>.GetNamed(matDefName, false);
                        if (mat == null && def.MadeFromStuff)
                            mat = GetDefaultMaterial(def);
                        var thing = ThingMaker.MakeThing(def, mat) as Apparel;
                        if (thing != null)
                        {
                            try
                            {
                                if (previewPawn.apparel.CanWearWithoutDroppingAnything(thing.def))
                                {
                                    previewPawn.apparel.Wear(thing);
                                    Log.Message($"[LoadoutEditor] Equipped {def.defName} [{mat?.defName ?? "-"}]");
                                }
                                else
                                {
                                    Log.Error($"[LoadoutEditor] Cannot wear {def.defName} - incompatible with current apparel");
                                }
                            }
                            catch (Exception ex)
                            {
                                Log.Error($"[LoadoutEditor] Failed to wear {def.defName}: {ex.Message}");
                            }
                        }
                        else
                            Log.Error($"[LoadoutEditor] Failed to create apparel: {def.defName}");
                    }
                }

                // Primary weapon
                if (!string.IsNullOrEmpty(currentLoadout.PrimaryWeapon))
                {
                    var def = DefDatabase<ThingDef>.GetNamed(currentLoadout.PrimaryWeapon, false);
                    if (def != null)
                    {
                        var thing = ThingMaker.MakeThing(def) as ThingWithComps;
                        if (thing != null)
                        {
                            previewPawn.equipment.AddEquipment(thing);
                            Log.Message($"[LoadoutEditor] Equipped primary weapon: {def.defName}");
                        }
                        else
                            Log.Error($"[LoadoutEditor] Failed to create primary weapon: {def.defName}");
                    }
                    else
                        Log.Error($"[LoadoutEditor] Primary weapon def not found: {currentLoadout.PrimaryWeapon}");
                }
            }
            else
            {
                Log.Error("[LoadoutEditor] Current loadout is null");
            }
        }

        private void ApplyLoadoutToPawn(Pawn pawn)
        {
            if (pawn == null) return;

            // Clear current equipment and apparel
            if (pawn.equipment != null)
            {
                var eqList = pawn.equipment.AllEquipmentListForReading.ToList();
                foreach (var eq in eqList)
                    pawn.equipment.Remove(eq);
            }
            if (pawn.apparel != null)
            {
                var appList = pawn.apparel.WornApparel.ToList();
                foreach (var app in appList)
                    pawn.apparel.Remove(app);
            }

            // Apply helmet
            if (!string.IsNullOrEmpty(currentLoadout.Helmet))
            {
                var def = DefDatabase<ThingDef>.GetNamed(currentLoadout.Helmet, false);
                if (def != null)
                {
                    string matDefName = null;
                    currentLoadout.ItemMaterials.TryGetValue(def.defName, out matDefName);
                    if (!string.IsNullOrEmpty(matDefName))
                    {
                        var mat = DefDatabase<ThingDef>.GetNamed(matDefName, false);
                        var thing = ThingMaker.MakeThing(def, mat) as Apparel;
                        if (thing != null)
                            pawn.apparel.Wear(thing);
                    }
                }
            }

            // Apply apparel
            foreach (var apparel in currentLoadout.Apparel)
            {
                var def = DefDatabase<ThingDef>.GetNamed(apparel, false);
                if (def != null)
                {
                    string matDefName = null;
                    currentLoadout.ItemMaterials.TryGetValue(def.defName, out matDefName);
                    if (!string.IsNullOrEmpty(matDefName))
                    {
                        var mat = DefDatabase<ThingDef>.GetNamed(matDefName, false);
                        var thing = ThingMaker.MakeThing(def, mat) as Apparel;
                        if (thing != null)
                            pawn.apparel.Wear(thing);
                    }
                }
            }

            // Apply primary weapon
            if (!string.IsNullOrEmpty(currentLoadout.PrimaryWeapon))
            {
                var def = DefDatabase<ThingDef>.GetNamed(currentLoadout.PrimaryWeapon, false);
                if (def != null)
                {
                    var thing = ThingMaker.MakeThing(def) as ThingWithComps;
                    if (thing != null)
                        pawn.equipment.AddEquipment(thing);
                }
            }

            // Apply secondary weapon to inventory instead of equipment
            if (!string.IsNullOrEmpty(currentLoadout.SecondaryWeapon))
            {
                var def = DefDatabase<ThingDef>.GetNamed(currentLoadout.SecondaryWeapon, false);
                if (def != null)
                {
                    var thing = ThingMaker.MakeThing(def) as ThingWithComps;
                    if (thing != null)
                        pawn.inventory.innerContainer.TryAdd(thing);
                }
            }

            // Apply medkits
            foreach (var medkit in currentLoadout.Medkits)
            {
                var def = DefDatabase<ThingDef>.GetNamed(medkit, false);
                if (def != null)
                {
                    var thing = ThingMaker.MakeThing(def);
                    if (thing != null)
                        pawn.inventory.innerContainer.TryAdd(thing);
                }
            }

            // Apply ammo
            foreach (var ammo in currentLoadout.Ammo)
            {
                var def = DefDatabase<ThingDef>.GetNamed(ammo.Key, false);
                if (def != null)
                {
                    var thing = ThingMaker.MakeThing(def);
                    if (thing != null)
                    {
                        thing.stackCount = ammo.Value;
                        pawn.inventory.innerContainer.TryAdd(thing);
                    }
                }
            }

            // Apply extra items
            foreach (var extra in currentLoadout.Extra)
            {
                var def = DefDatabase<ThingDef>.GetNamed(extra, false);
                if (def != null)
                {
                    var thing = ThingMaker.MakeThing(def);
                    if (thing != null)
                        pawn.inventory.innerContainer.TryAdd(thing);
                }
            }
        }

        // Dialog for editing ammo count
        public class Dialog_EditValue : Window
        {
            private string buffer;
            private readonly string key;
            private int value;
            private readonly Action<int> onConfirm;
            public override Vector2 InitialSize => new Vector2(300f, 120f);
            public Dialog_EditValue(string key, int value, Action<int> onConfirm)
            {
                this.key = key;
                this.value = value;
                this.onConfirm = onConfirm;
                buffer = value.ToString();
                doCloseX = true;
                forcePause = true;
            }
            public override void DoWindowContents(Rect inRect)
            {
                Widgets.Label(new Rect(0, 0, inRect.width, 32f), $"Set amount for {key}:");
                Widgets.TextFieldNumeric(new Rect(0, 40f, inRect.width - 10f, 32f), ref value, ref buffer, 1, 9999);
                if (Widgets.ButtonText(new Rect(0, 80f, inRect.width, 32f), "OK"))
                {
                    onConfirm(value);
                    Close();
                }
            }
        }
    }
} 