﻿using System.Collections.Generic;
using UnityEngine;
using Verse;
using RimWorld;
using HarmonyLib;

namespace SuperColonyBuffs
{
    [HarmonyPatch(typeof(FloatMenuMakerMap), "AddHumanlikeOrders")]
    public static class Patch_FloatMenuMakerMap_AddHumanlikeOrders
    {
        static void Postfix(Vector3 clickPos, Pawn pawn, ref List<FloatMenuOption> opts)
        {
            // Only allow the clicking pawn to be a colonist under player control
            if (pawn == null || !pawn.IsColonist || pawn.Faction != Faction.OfPlayer) return;

            // Convert click position to a map cell
            IntVec3 targetCell = IntVec3.FromVector3(clickPos);
            Map map = pawn.Map;

            // Ensure the target cell is valid
            if (!targetCell.InBounds(map)) return;

            // Add the "Airstrike" option
            opts.Add(new FloatMenuOption("Airstrike", () =>
            {
                // Define the radius and explosion parameters
                float radius = 15f; // 5-tile radius for the airstrike
                int explosionCount = 30; // Number of explosions to simulate the barrage

                for (int i = 0; i < explosionCount; i++)
                {
                    // Randomize position within the radius
                    IntVec3 explosionCell = targetCell + GenRadial.RadialPattern[Rand.Range(0, GenRadial.NumCellsInRadius(radius))];
                    if (!explosionCell.InBounds(map)) continue;

                    // Create an explosion (similar to a mortar shell)
                    GenExplosion.DoExplosion(
                        center: explosionCell,
                        map: map,
                        radius: 6f, // Small explosion radius per strike
                        damType: DamageDefOf.Bomb, // Changed from damageDef to damType
                        instigator: null,
                        damAmount: 350, // Damage per explosion
                        armorPenetration: -1f,
                        explosionSound: null,
                        weapon: null,
                        projectile: null,
                        intendedTarget: null,
                        postExplosionSpawnThingDef: null,
                        postExplosionSpawnChance: 0f,
                        postExplosionSpawnThingCount: 0,
                        applyDamageToExplosionCellsNeighbors: false,
                        preExplosionSpawnThingDef: null,
                        preExplosionSpawnChance: 0f,
                        preExplosionSpawnThingCount: 0,
                        chanceToStartFire: 0.2f,
                        damageFalloff: true
                    );
                }
                Messages.Message($"Airstrike called at position {targetCell}.", MessageTypeDefOf.NeutralEvent);
            }));
        }
    }
}