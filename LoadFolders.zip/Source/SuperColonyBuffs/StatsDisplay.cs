﻿using HarmonyLib;
using UnityEngine;
using Verse;
using System;
using RimWorld;

namespace SuperColonyBuffs
{
    [HarmonyPatch]
    public static class StatsDisplay
    {
        private static float lastTickTime = 0f;
        private static int tickCount = 0;
        private static float tps = 0f;
        private static float lastUpdateTime = 0f;
        private const float updateInterval = 1f;
        private static float[] targetTPSBySpeed = new float[5];
        private static bool isCalibrating = false;
        private static int calibrationSpeedIndex = -1;

        public static bool showFPS = true;
        public static bool showExactTPS = false;

        static StatsDisplay()
        {
            Log.Message("[StatsDisplay] Static constructor running");
        }

        private static void SetPaused(bool paused)
        {
            if (Find.TickManager != null)
            {
                var pausedProperty = typeof(TickManager).GetProperty("Paused");
                if (pausedProperty != null && pausedProperty.CanWrite)
                {
                    pausedProperty.SetValue(Find.TickManager, paused, null);
                }
                else
                {
                    Log.Error("Failed to set TickManager.Paused: Property not found or read-only.");
                }
            }
        }

        public static void DrawStats(Rect rect)
        {
            float currentTime = Time.realtimeSinceStartup;
            tickCount++;

            if (currentTime - lastUpdateTime >= updateInterval)
            {
                float deltaTime = currentTime - lastUpdateTime;
                if (deltaTime > 0)
                {
                    tps = tickCount / deltaTime;
                }
                lastUpdateTime = currentTime;
                lastTickTime = currentTime;
                tickCount = 0;
            }

            float targetTPS = 0f;
            int currentSpeedIndex = Find.TickManager != null ? (int)Find.TickManager.CurTimeSpeed : 0;
            if (currentSpeedIndex >= 0 && currentSpeedIndex < targetTPSBySpeed.Length)
            {
                targetTPS = targetTPSBySpeed[currentSpeedIndex];
                if (targetTPS == 0f && !isCalibrating)
                {
                    isCalibrating = true;
                    calibrationSpeedIndex = currentSpeedIndex;
                    if (Find.TickManager.Paused)
                    {
                        SetPaused(false);
                    }
                    Find.TickManager.CurTimeSpeed = (TimeSpeed)currentSpeedIndex;
                }
            }

            if (targetTPS == 0f)
            {
                targetTPS = 60f * (currentSpeedIndex + 1);
            }

            string tpsText = showExactTPS ? tps.ToString("F2") : Mathf.Round(tps).ToString();
            string displayText = $"TPS: {tpsText} ({targetTPS:F0})";

            if (showFPS)
            {
                float fps = 1f / Time.deltaTime;
                string fpsText = showExactTPS ? fps.ToString("F2") : Mathf.Round(fps).ToString();
                displayText += $"\nFPS: {fpsText}";
            }

            GUI.BeginGroup(rect);
            GUI.color = Color.white;
            Widgets.Label(new Rect(0, 0, rect.width, rect.height), displayText);
            GUI.EndGroup();
        }

        [HarmonyPatch(typeof(UIRoot_Play), "UIRootOnGUI")]
        [HarmonyPostfix]
        public static void Postfix_UIRootOnGUI()
        {
            if (Current.Game == null) return; // Only draw when in-game
            float x = UI.screenWidth - 210f;
            float y = UI.screenHeight - 110f;
            float width = 200f;
            float height = showFPS ? 50f : 25f;
            Rect rect = new Rect(x, y, width, height);
            DrawStats(rect);
        }

        [HarmonyPatch(typeof(TickManager), nameof(TickManager.DoSingleTick))]
        [HarmonyPostfix]
        public static void OnTick()
        {
            tickCount++;
        }
    }
}