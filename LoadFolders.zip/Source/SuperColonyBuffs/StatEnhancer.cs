﻿using System.Collections.Generic;
using Verse;
using RimWorld;
using HarmonyLib;
using System.Linq;

namespace SuperColonyBuffs
{
    // Define the Hediff for the Stat Enhancer
    public class Hediff_StatEnhancer : HediffWithComps
    {
        private float statMultiplier = 1f; // Default multiplier (1 = no change)

        // Property to set the multiplier based on the chosen setting
        public float StatMultiplier
        {
            get => statMultiplier;
            set => statMultiplier = value;
        }

        // Override to save/load the multiplier
        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref statMultiplier, "statMultiplier", 1f);
        }

        // Initialize the hediff and log for debugging
        public override void PostAdd(DamageInfo? dinfo)
        {
            base.PostAdd(dinfo);
            Log.Message($"Hediff_StatEnhancer applied to {pawn.Label} with multiplier {statMultiplier}");

            // Set severity based on multiplier
            if (statMultiplier == 500f)
                Severity = 0.5f; // 5x stage
            else if (statMultiplier == 1000f)
                Severity = 1.0f; // 10x stage
            else if (statMultiplier == 1500f)
                Severity = 1.5f; // 15x stage
        }
    }

    // Static class to handle float menu options
    public static class StatEnhancer
    {
        // Harmony patch to add the "Enhance Stats" float menu option
        [HarmonyPatch(typeof(Pawn), "GetFloatMenuOptions")]
        public static class Patch_Pawn_GetFloatMenuOptions
        {
            static void Postfix(Pawn __instance, ref IEnumerable<FloatMenuOption> __result)
            {
                List<FloatMenuOption> options = new List<FloatMenuOption>(__result);

                // Only allow the clicking pawn to be a colonist under player control
                if (__instance == null || !__instance.IsColonist || __instance.Faction != Faction.OfPlayer) return;

                // Add the "Enhance Stats" menu
               // options.Add(new FloatMenuOption("test-stats", () =>
               // {
                //    List<FloatMenuOption> statOptions = GetEnhanceStatsFloatMenuOptions(__instance).ToList();
                //    FloatMenu subMenu = new FloatMenu(statOptions);
                 //   Find.WindowStack.Add(subMenu);
                //}));

                //__result = options;
            }
        }

        // Method to generate Enhance Stats sub-menu options
        public static IEnumerable<FloatMenuOption> GetEnhanceStatsFloatMenuOptions(Pawn pawn)
        {
            // "5k%" option
            yield return new FloatMenuOption("5k%", () =>
            {
                ApplyStatEnhancer(pawn, 500f); // 5x multiplier
                Messages.Message($"{pawn.Label}'s stats have been enhanced to 500%.", MessageTypeDefOf.PositiveEvent);
            });

            // "10k%" option
            yield return new FloatMenuOption("10k%", () =>
            {
                ApplyStatEnhancer(pawn, 1000f); // 10x multiplier
                Messages.Message($"{pawn.Label}'s stats have been enhanced to 1,000%.", MessageTypeDefOf.PositiveEvent);
            });

            // "15k%" option
            yield return new FloatMenuOption("15k%", () =>
            {
                ApplyStatEnhancer(pawn, 1500f); // 15x multiplier
                Messages.Message($"{pawn.Label}'s stats have been enhanced to 1,500%.", MessageTypeDefOf.PositiveEvent);
            });

            // "Reset to Default" option
            yield return new FloatMenuOption("Reset to Default", () =>
            {
                Hediff existingHediff = pawn.health.hediffSet.GetFirstHediffOfDef(DefDatabase<HediffDef>.GetNamed("Hediff_StatEnhancer", false));
                if (existingHediff != null)
                {
                    pawn.health.RemoveHediff(existingHediff);
                    Messages.Message($"{pawn.Label}'s stats have been reset to default.", MessageTypeDefOf.NeutralEvent);
                }
                else
                {
                    Messages.Message($"{pawn.Label} has no Stat Enhancer to reset.", MessageTypeDefOf.RejectInput);
                }
            });
        }

        // Helper method to apply the stat enhancer hediff
        private static void ApplyStatEnhancer(Pawn pawn, float percentage)
        {
            // Remove any existing StatEnhancer hediff
            Hediff existingHediff = pawn.health.hediffSet.GetFirstHediffOfDef(DefDatabase<HediffDef>.GetNamed("Hediff_StatEnhancer", false));
            if (existingHediff != null)
            {
                pawn.health.RemoveHediff(existingHediff);
            }

            // Apply the new hediff with the chosen percentage
            Hediff_StatEnhancer statEnhancer = (Hediff_StatEnhancer)HediffMaker.MakeHediff(DefDatabase<HediffDef>.GetNamed("Hediff_StatEnhancer"), pawn);
            statEnhancer.StatMultiplier = percentage;
            pawn.health.AddHediff(statEnhancer);
        }
    }
}