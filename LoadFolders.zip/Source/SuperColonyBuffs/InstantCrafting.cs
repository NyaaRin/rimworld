using HarmonyLib;
using Verse;
using RimWorld;

namespace SuperColonyBuffs
{
    [HarmonyPatch(typeof(Bill), "GetWorkAmount")]
    public static class Patch_Bill_GetWorkAmount
    {
        static bool Prefix(ref float __result)
        {
            if (ModSettings.instantCrafting)
            {
                __result = 0f;
                return false;
            }
            return true;
        }
    }
}