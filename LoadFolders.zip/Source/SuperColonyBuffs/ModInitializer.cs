﻿using System;
using RimWorld;
using Verse;
using System.IO;
using UnityEngine;
using CombatExtended;

namespace SuperColonyBuffs
{
    public class ModInitializer : Mod
    {
        private ModSettings settings;

        public ModInitializer(ModContentPack content) : base(content)
        {
            settings = GetSettings<ModSettings>();
            Log.Message("[SuperColonyBuffs] Mod initializing...");
            Log.Message($"[SuperColonyBuffs] Mod content path: {content.RootDir}");
            Log.Message($"[SuperColonyBuffs] Mods folder path: {GenFilePaths.ModsFolderPath}");
            LongEventHandler.ExecuteWhenFinished(() =>
            {
                try
                {
                    Log.Message("[SuperColonyBuffs] Starting loadout initialization...");
                    LoadoutManager.Initialize();
                    Log.Message("[SuperColonyBuffs] Loadout initialization complete");
                }
                catch (Exception ex)
                {
                    Log.Error($"[SuperColonyBuffs] Failed to initialize mod: {ex.Message}\nStack trace: {ex.StackTrace}");
                }
            });
        }

        public override string SettingsCategory()
        {
            return "Super Colony Buffs";
        }

        public override void DoSettingsWindowContents(Rect inRect)
        {
            ModSettings.DoSettingsWindowContents(inRect);
            base.DoSettingsWindowContents(inRect);
        }
    }
}