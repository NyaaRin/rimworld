using UnityEngine;
using Verse;
using RimWorld;

namespace SuperColonyBuffs
{
    public class ModSettings : Verse.ModSettings
    {
        public static bool applyToPrisoners = true;
        public static bool applyToSlaves = true;
        public static bool infiniteResources = true;
        public static bool instantCrafting = true;
        public static bool preserveResourcesMode = false;
        public static bool preserveGear = true;
        public static bool preserveStructures = true;
        public static bool autoApplySuperBuff = true;
        public static bool showExactTPS = false;
        public static bool showFPS = true;
        public static bool infiniteAmmo = false;
        public static bool debugMode = false;
        public static bool instantCropGrowth = false; // New setting for instant crop growth

        public override void ExposeData()
        {
            Scribe_Values.Look(ref applyToPrisoners, "applyToPrisoners", true);
            Scribe_Values.Look(ref applyToSlaves, "applyToSlaves", true);
            Scribe_Values.Look(ref infiniteResources, "infiniteResources", true);
            Scribe_Values.Look(ref instantCrafting, "instantCrafting", true);
            Scribe_Values.Look(ref preserveResourcesMode, "preserveResourcesMode", false);
            Scribe_Values.Look(ref preserveGear, "preserveGear", true);
            Scribe_Values.Look(ref preserveStructures, "preserveStructures", true);
            Scribe_Values.Look(ref autoApplySuperBuff, "autoApplySuperBuff", true);
            Scribe_Values.Look(ref showExactTPS, "showExactTPS", false);
            Scribe_Values.Look(ref showFPS, "showFPS", true);
            Scribe_Values.Look(ref infiniteAmmo, "infiniteAmmo", false);
            Scribe_Values.Look(ref debugMode, "debugMode", false);
            Scribe_Values.Look(ref instantCropGrowth, "instantCropGrowth", false); // Save/load new setting
            if (Scribe.mode == LoadSaveMode.Saving && debugMode)
            {
                Log.Message($"[SuperColonyBuffs] Saving settings: debugMode={debugMode}, infiniteAmmo={infiniteAmmo}, instantCropGrowth={instantCropGrowth}");
            }
            base.ExposeData();
        }

        public static void DoSettingsWindowContents(Rect inRect)
        {
            Listing_Standard listing = new Listing_Standard();
            listing.Begin(inRect);

            listing.Label("Super Colony Buffs Settings");
            listing.CheckboxLabeled("Apply buffs to prisoners", ref applyToPrisoners, "If checked, prisoners receive max needs buffs and gear preservation.");
            listing.CheckboxLabeled("Apply buffs to slaves", ref applyToSlaves, "If checked, slaves receive max needs buffs and gear preservation.");
            listing.CheckboxLabeled("Enable infinite resources", ref infiniteResources, "If checked, resources in stockpiles with at least 1 unit become infinite.");
            listing.CheckboxLabeled("Preserve resources mode", ref preserveResourcesMode, "If checked, resources won't decrease when used (overrides infinite mode).");
            listing.CheckboxLabeled("Enable instant crafting", ref instantCrafting, "If checked, all crafting jobs complete instantly.");
            listing.CheckboxLabeled("Preserve gear (weapons/armor)", ref preserveGear, "If checked, weapons and armor won't deteriorate for eligible pawns.");
            listing.CheckboxLabeled("Preserve structures", ref preserveStructures, "If checked, player-owned structures won't deteriorate over time.");
            listing.CheckboxLabeled("Auto-apply SuperBuff", ref autoApplySuperBuff, "If checked, SuperBuff (including mood, food, rest, and comfort) is automatically applied to eligible pawns. Manual toggle still works.");
            listing.CheckboxLabeled("Show exact TPS", ref showExactTPS, "If checked, displays TPS with decimal precision (e.g., 56.70); otherwise rounds to nearest integer (e.g., 57).");
            listing.CheckboxLabeled("Show average FPS", ref showFPS, "If checked, displays average FPS below TPS.");
            listing.CheckboxLabeled("Enable turret infinite ammo", ref infiniteAmmo, "If checked, all turrets using Combat Extended ammo or vanilla ammo have infinite rounds.");
            listing.CheckboxLabeled("Enable instant crop growth", ref instantCropGrowth, "If checked, all crops grow to full maturity instantly every tick."); // New checkbox
            listing.CheckboxLabeled("Enable debug mode", ref debugMode, "If checked, enables detailed logging for debugging purposes.");
            if (listing.ButtonText("Toggle Infinite Ammo"))
            {
                infiniteAmmo = !infiniteAmmo;
                Log.Message($"[SuperColonyBuffs] Toggled infiniteAmmo to {infiniteAmmo}");
            }

            listing.End();
        }
    }
}