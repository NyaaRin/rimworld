﻿using HarmonyLib;
using RimWorld;
using Verse;
using UnityEngine;
using CombatExtended;
using System.Collections.Generic;

namespace SuperColonyBuffs
{
    // Component for per-pawn infinite ammo toggle
    public class CompInfiniteAmmoPawn : ThingComp
    {
        public bool hasInfiniteAmmo = false;

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_Values.Look(ref hasInfiniteAmmo, "hasInfiniteAmmo", false);
            if (Scribe.mode == LoadSaveMode.LoadingVars && hasInfiniteAmmo && ModSettings.debugMode)
            {
                Log.Message($"[SuperColonyBuffs] InfiniteAmmo: Loaded hasInfiniteAmmo=true for {parent?.LabelCap ?? "unknown"}");
            }
        }

        public override IEnumerable<Gizmo> CompGetGizmosExtra()
        {
            Pawn pawn = parent as Pawn;
            if (pawn == null || pawn.Dead || pawn.Map == null)
            {
                Log.Warning($"[SuperColonyBuffs] InfiniteAmmo: Skipping gizmo for invalid pawn {parent?.LabelCap ?? "null"}.");
                yield break;
            }

            if (pawn.IsColonist)
            {
                yield return new Command_Action
                {
                    defaultLabel = "InfAmmo Options",
                    defaultDesc = "Toggle infinite ammo for this pawn.",
                    icon = ContentFinder<Texture2D>.Get("UI/Commands/Reload", false) ?? TexCommand.Draft,
                    action = () =>
                    {
                        List<FloatMenuOption> options = new List<FloatMenuOption>
                        {
                            new FloatMenuOption(
                                hasInfiniteAmmo ? "Disable InfAmmo" : "Enable InfAmmo",
                                () =>
                                {
                                    hasInfiniteAmmo = !hasInfiniteAmmo;
                                    Messages.Message($"{pawn.LabelCap}'s infinite ammo {(hasInfiniteAmmo ? "enabled" : "disabled")}.", MessageTypeDefOf.NeutralEvent);
                                    if (hasInfiniteAmmo && pawn.equipment?.Primary != null)
                                    {
                                        ThingWithComps weapon = pawn.equipment.Primary;
                                        CompAmmoUser compAmmo = weapon.TryGetComp<CompAmmoUser>();
                                        if (compAmmo != null && compAmmo.Props != null && compAmmo.Props.ammoSet != null && !compAmmo.Props.ammoSet.ammoTypes.NullOrEmpty())
                                        {
                                            compAmmo.CurMagCount = compAmmo.MagSize;
                                            if (ModSettings.debugMode)
                                            {
                                                Log.Message($"[SuperColonyBuffs] InfiniteAmmo: Initialized ammo for {pawn.LabelCap}'s {weapon.def.defName} to {compAmmo.CurMagCount}");
                                            }
                                        }
                                        else
                                        {
                                            Log.Warning($"[SuperColonyBuffs] InfiniteAmmo: Could not initialize ammo for {pawn.LabelCap}'s {weapon.def.defName} (invalid CompAmmoUser or ammoSet).");
                                        }
                                    }
                                })
                        };
                        Find.WindowStack.Add(new FloatMenu(options));
                    }
                };
            }
        }
    }

    // Add CompInfiniteAmmoPawn to pawns
    [StaticConstructorOnStartup]
    public static class PawnCompPatcher
    {
        static PawnCompPatcher()
        {
            var pawnDef = DefDatabase<ThingDef>.GetNamed("Human", false);
            if (pawnDef != null)
            {
                if (pawnDef.comps == null)
                {
                    pawnDef.comps = new List<CompProperties>();
                    if (ModSettings.debugMode)
                    {
                        Log.Message("[SuperColonyBuffs] InfiniteAmmo: Initialized comps list for Human pawn def.");
                    }
                }
                if (!pawnDef.comps.Any(comp => comp.compClass == typeof(CompInfiniteAmmoPawn)))
                {
                    pawnDef.comps.Add(new CompProperties { compClass = typeof(CompInfiniteAmmoPawn) });
                    Log.Message("[SuperColonyBuffs] InfiniteAmmo: Added CompInfiniteAmmoPawn to Human pawn def.");
                }
            }
            else
            {
                Log.Error("[SuperColonyBuffs] InfiniteAmmo: Failed to find Human pawn def.");
            }
        }
    }

    // Patch for vanilla turrets (CompRefuelable)
    [HarmonyPatch(typeof(CompRefuelable), "ConsumeFuel")]
    public static class CompRefuelable_ConsumeFuel_Patch
    {
        static bool Prefix(CompRefuelable __instance)
        {
            if (__instance == null)
            {
                Log.Warning("[SuperColonyBuffs] InfiniteAmmo: CompRefuelable is null in ConsumeFuel.");
                return true;
            }

            if (ModSettings.infiniteAmmo)
            {
                if (ModSettings.debugMode)
                {
                    Log.Message($"[SuperColonyBuffs] InfiniteAmmo: Skipping fuel consumption for {__instance.parent?.Label ?? "unknown"}.");
                }
                return false; // Skip fuel consumption if global infinite ammo is enabled
            }
            return true; // Proceed with normal fuel consumption
        }
    }

    // Patch for CE ammo reduction (CompAmmoUser)
    [HarmonyPatch(typeof(CompAmmoUser), "TryReduceAmmoCount")]
    public static class CompAmmoUser_TryReduceAmmoCount_Patch
    {
        static void Postfix(CompAmmoUser __instance)
        {
            if (__instance == null || __instance.Props == null || __instance.Props.ammoSet == null || __instance.Props.ammoSet.ammoTypes.NullOrEmpty())
            {
                Log.Warning($"[SuperColonyBuffs] InfiniteAmmo: Invalid CompAmmoUser or ammoSet for {__instance.parent?.Label ?? "unknown"} in TryReduceAmmoCount.");
                return;
            }

            try
            {
                bool refilled = false;
                if (__instance.parent is Pawn pawn)
                {
                    var comp = pawn.TryGetComp<CompInfiniteAmmoPawn>();
                    if (comp != null && comp.hasInfiniteAmmo)
                    {
                        __instance.CurMagCount = __instance.MagSize; // Refill magazine for pawns with per-pawn infinite ammo
                        refilled = true;
                    }
                }
                else if (ModSettings.infiniteAmmo)
                {
                    __instance.CurMagCount = __instance.MagSize; // Refill magazine for turrets if global infinite ammo is enabled
                    refilled = true;
                }

                if (refilled && ModSettings.debugMode)
                {
                    Log.Message($"[SuperColonyBuffs] InfiniteAmmo: Refilled magazine for {__instance.parent?.Label ?? "unknown"} to {__instance.CurMagCount}.");
                }
            }
            catch (System.Exception ex)
            {
                Log.Error($"[SuperColonyBuffs] InfiniteAmmo: Failed to process TryReduceAmmoCount for {__instance.parent?.Label ?? "unknown"}. Error: {ex.Message}");
            }
        }
    }

    // Float menu for infinite ammo toggle
    public static class InfiniteAmmoFloatMenu
    {
        public static IEnumerable<FloatMenuOption> GetInfiniteAmmoFloatMenuOptions(Pawn pawn)
        {
            List<FloatMenuOption> options = new List<FloatMenuOption>();

            if (pawn == null)
            {
                Log.Warning("[SuperColonyBuffs] InfiniteAmmo: Cannot generate float menu for null pawn.");
                return options;
            }

            if (ModLister.GetActiveModWithIdentifier("ceteam.combatextended") != null)
            {
                var comp = pawn.TryGetComp<CompInfiniteAmmoPawn>();
                if (comp != null)
                {
                    string ammoLabel = comp.hasInfiniteAmmo ? "Disable Infinite Ammo" : "Enable Infinite Ammo";
                    options.Add(new FloatMenuOption(ammoLabel, () =>
                    {
                        comp.hasInfiniteAmmo = !comp.hasInfiniteAmmo;
                        Messages.Message($"{pawn.Label}'s infinite ammo {(comp.hasInfiniteAmmo ? "enabled" : "disabled")}.", MessageTypeDefOf.NeutralEvent);
                        if (comp.hasInfiniteAmmo && pawn.equipment?.Primary != null)
                        {
                            ThingWithComps weapon = pawn.equipment.Primary;
                            CompAmmoUser compAmmo = weapon.TryGetComp<CompAmmoUser>();
                            if (compAmmo != null && compAmmo.Props != null && compAmmo.Props.ammoSet != null && !compAmmo.Props.ammoSet.ammoTypes.NullOrEmpty())
                            {
                                compAmmo.CurMagCount = compAmmo.MagSize;
                                if (ModSettings.debugMode)
                                {
                                    Log.Message($"[SuperColonyBuffs] InfiniteAmmo: Initialized ammo for {pawn.Label}'s {weapon.def.defName} to {compAmmo.CurMagCount}");
                                }
                            }
                            else
                            {
                                Log.Warning($"[SuperColonyBuffs] InfiniteAmmo: Could not initialize ammo for {pawn.Label}'s {weapon.def.defName} (invalid CompAmmoUser or ammoSet).");
                            }
                        }
                    }));
                }
                else
                {
                    Log.Warning($"[SuperColonyBuffs] InfiniteAmmo: Pawn {pawn.Label} has no CompInfiniteAmmoPawn.");
                }
            }

            return options;
        }
    }
}