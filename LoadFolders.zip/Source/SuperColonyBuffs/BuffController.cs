using Verse;
using RimWorld;
using UnityEngine;
using System.Collections.Generic;

namespace SuperColonyBuffs
{
    public class CompProperties_BuffController : CompProperties
    {
        public CompProperties_BuffController()
        {
            compClass = typeof(BuffController);
        }
    }

    public class BuffController : ThingComp
    {
        private bool isBuffManuallyEnabled = false;

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_Values.Look(ref isBuffManuallyEnabled, "isBuffManuallyEnabled", false);
        }

        public override void CompTick()
        {
            base.CompTick();
            Pawn pawn = parent as Pawn;
            if (pawn == null || pawn.Dead || pawn.Map == null) return;

            bool applyBuff = ModSettings.autoApplySuperBuff &&
                            (pawn.IsColonist ||
                             (pawn.IsPrisoner && ModSettings.applyToPrisoners) ||
                             (pawn.IsSlave && ModSettings.applyToSlaves));

            if (applyBuff || isBuffManuallyEnabled)
            {
                HediffDef buffDef = DefDatabase<HediffDef>.GetNamed("Hediff_SuperBuff", false);
                if (buffDef != null)
                {
                    Hediff hediff = pawn.health.hediffSet.GetFirstHediffOfDef(buffDef);
                    if (hediff == null)
                    {
                        hediff = HediffMaker.MakeHediff(buffDef, pawn);
                        pawn.health.AddHediff(hediff);
                    }
                }

                if (pawn.needs?.mood != null) pawn.needs.mood.CurLevelPercentage = 1f;
                if (pawn.needs?.food != null) pawn.needs.food.CurLevelPercentage = 1f;
                if (pawn.needs?.rest != null) pawn.needs.rest.CurLevelPercentage = 1f;
                if (pawn.needs?.comfort != null) pawn.needs.comfort.CurLevelPercentage = 1f;
            }
            else
            {
                HediffDef buffDef = DefDatabase<HediffDef>.GetNamed("Hediff_SuperBuff", false);
                if (buffDef != null)
                {
                    Hediff hediff = pawn.health.hediffSet.GetFirstHediffOfDef(buffDef);
                    if (hediff != null)
                    {
                        pawn.health.RemoveHediff(hediff);
                    }
                }
            }
        }

        public override IEnumerable<Gizmo> CompGetGizmosExtra()
        {
            Pawn pawn = parent as Pawn;
            if (pawn == null || pawn.Dead || pawn.Map == null) yield break;

            bool canReceiveBuff = pawn.IsColonist ||
                                 pawn.IsPrisoner ||
                                 pawn.IsSlave;

            if (canReceiveBuff)
            {
                yield return new Command_Toggle
                {
                    defaultLabel = "Toggle SuperBuff",
                    defaultDesc = "Enable or disable the SuperBuff effect on this pawn.",
                    icon = ContentFinder<Texture2D>.Get("UI/Commands/SuperBuffIcon", false) ?? TexCommand.ForbidOff,
                    isActive = () => isBuffManuallyEnabled,
                    toggleAction = () =>
                    {
                        isBuffManuallyEnabled = !isBuffManuallyEnabled;
                    }
                };
            }
        }
    }
}
