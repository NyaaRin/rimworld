﻿using RimWorld;
using Verse;
using System.Collections.Generic;
using System.Linq;
using System;

namespace SuperColonyBuffs.TechBurst
{
    public static class TechBurstFloatMenu
    {
        // Cache body part definitions
        private static readonly BodyPartDef HeartDef = DefDatabase<BodyPartDef>.GetNamed("Heart");
        private static readonly BodyPartDef LungDef = DefDatabase<BodyPartDef>.GetNamed("Lung");
        private static readonly BodyPartDef EarDef = DefDatabase<BodyPartDef>.GetNamed("Ear");
        private static readonly BodyPartDef JawDef = DefDatabase<BodyPartDef>.GetNamed("Jaw");
        private static readonly BodyPartDef StomachDef = DefDatabase<BodyPartDef>.GetNamed("Stomach");
        private static readonly BodyPartDef KidneyDef = DefDatabase<BodyPartDef>.GetNamed("Kidney");
        private static readonly BodyPartDef LiverDef = DefDatabase<BodyPartDef>.GetNamed("Liver");
        private static readonly BodyPartDef SpineDef = DefDatabase<BodyPartDef>.GetNamed("Spine");
        private static readonly BodyPartDef BrainDef = DefDatabase<BodyPartDef>.GetNamed("Brain");
        private static readonly BodyPartDef ArmDef = DefDatabase<BodyPartDef>.GetNamed("Arm");
        private static readonly BodyPartDef HandDef = DefDatabase<BodyPartDef>.GetNamed("Hand");
        private static readonly BodyPartDef LegDef = DefDatabase<BodyPartDef>.GetNamed("Leg");
        private static readonly BodyPartDef TorsoDef = DefDatabase<BodyPartDef>.GetNamed("Torso");
        private static readonly BodyPartDef TongueDef = DefDatabase<BodyPartDef>.GetNamed("Tongue");
        private static readonly BodyPartDef ShoulderDef = DefDatabase<BodyPartDef>.GetNamed("Shoulder");

        public static void ApplyTechBurst(Pawn pawn)
        {
            // Apply each implant individually
            // Elbow Blade (on both shoulders)
            ApplyImplant(pawn, "ElbowBlade", ShoulderDef, p => p.def == ShoulderDef);

            // Bionic Ear (on both ears)
            ApplyImplant(pawn, "BionicEar", EarDef, p => p.def == EarDef);

            // Bionic Jaw
            ApplyImplant(pawn, "BionicJaw", JawDef, p => p.def == JawDef);

            // Venom Fangs (on jaw)
            ApplyImplant(pawn, "VenomFangs", JawDef, p => p.def == JawDef);

            // Bionic Stomach
            ApplyImplant(pawn, "BionicStomach", StomachDef, p => p.def == StomachDef);

            // Bionic Heart
            ApplyImplant(pawn, "BionicHeart", HeartDef, p => p.def == HeartDef);

            // Revenant Vertebrae (on spine)
            ApplyImplant(pawn, "RevenantVertebrae", SpineDef, p => p.def == SpineDef);

            // Healing Enhancer (on torso)
            ApplyImplant(pawn, "HealingEnhancer", TorsoDef, p => p.def == TorsoDef);

            // Coagulator (on torso)
            ApplyImplant(pawn, "Coagulator", TorsoDef, p => p.def == TorsoDef);

            // Brain Implants
            ApplyImplant(pawn, "CircadianAssistant", BrainDef, p => p.def == BrainDef);
            ApplyImplant(pawn, "CircadianHalfCycler", BrainDef, p => p.def == BrainDef);
            ApplyImplant(pawn, "LearningAssistant", BrainDef, p => p.def == BrainDef);
            ApplyImplant(pawn, "Painstopper", BrainDef, p => p.def == BrainDef);
            ApplyImplant(pawn, "PsychicReader", BrainDef, p => p.def == BrainDef);
            ApplyImplant(pawn, "PsychicHarmonizer", BrainDef, p => p.def == BrainDef);

            // Toughskin Gland (on torso)
            ApplyImplant(pawn, "ToughskinGland", TorsoDef, p => p.def == TorsoDef);

            Messages.Message($"{pawn.Label} has been upgraded with TechBurst implants.", MessageTypeDefOf.PositiveEvent);
        }

        private static void ApplyImplant(Pawn pawn, string hediffDefName, BodyPartDef targetPartDef, Func<BodyPartRecord, bool> partPredicate)
        {
            HediffDef hediffDef = DefDatabase<HediffDef>.GetNamed(hediffDefName, false);
            if (hediffDef == null)
            {
                Log.Warning($"[SuperColonyBuffs] TechBurst: Could not find HediffDef {hediffDefName}");
                return;
            }

            var bodyDef = pawn.RaceProps.body;
            // Find all matching parts (e.g., both left and right shoulders, ears, hands, etc.)
            var parts = bodyDef.AllParts.Where(partPredicate).ToList();

            if (!parts.Any())
            {
                // Check if the parts are missing and restore them
                var missingHediffs = pawn.health.hediffSet.hediffs
                    .Where(h => h.def == HediffDefOf.MissingBodyPart && h.Part?.def == targetPartDef)
                    .ToList();

                if (missingHediffs.Any())
                {
                    foreach (var missingHediff in missingHediffs)
                    {
                        // Restore the part using RimWorld's built-in method
                        pawn.health.RestorePart(missingHediff.Part);
                    }

                    // Re-check for the parts after restoration
                    parts = bodyDef.AllParts.Where(partPredicate).ToList();
                    if (!parts.Any())
                    {
                        Log.Warning($"[SuperColonyBuffs] TechBurst: Could not restore body part {targetPartDef.defName} for {hediffDefName} on {pawn.Label}");
                        return;
                    }
                }
                else
                {
                    Log.Warning($"[SuperColonyBuffs] TechBurst: No valid body part for {hediffDefName} on {pawn.Label}");
                    return;
                }
            }

            // Apply the implant to all matching parts
            foreach (var part in parts)
            {
                // Remove only conflicting hediffs of the same type to allow multiple implants on the same part
                var existingHediffs = pawn.health.hediffSet.hediffs
                    .Where(h => h.Part == part && h.def == hediffDef)
                    .ToList();
                foreach (var hediff in existingHediffs)
                {
                    pawn.health.RemoveHediff(hediff);
                }

                // Add the new hediff
                Hediff addedPart = HediffMaker.MakeHediff(hediffDef, pawn, part);
                pawn.health.AddHediff(addedPart, part);
            }
        }
    }
}