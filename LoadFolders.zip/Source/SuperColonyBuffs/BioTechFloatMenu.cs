﻿using RimWorld;
using Verse;
using System.Collections.Generic;
using System.Linq;

namespace SuperColonyBuffs.BioTech
{
    public static class BioTechFloatMenu
    {
        // Define gene lists for each category
        private static readonly string[] HealingGenes = new[]
        {
            "WoundHealing_SuperFast",
            "Superclotting", "PerfectImmunity", "TotalHealing", "Coagulate", "DiseaseFree"
        };

        private static readonly string[] CombatGenes = new[]
        {
            "MeleeDamage_Strong", "Robust", "MoveSpeed_VeryQuick", "Unstoppable",
            "PiercingSpine", "AptitudeRemarkable_Shooting",
            "AptitudeRemarkable_Melee", "GreatShooting", "GreatMelee"
        };

        private static readonly string[] UtilityGenes = new[]
        {
            "StrongStomach", "RobustDigestion", "DarkVision", "Neversleep",
            "AnimalWarcall", "FoamSpray", "AptitudeRemarkable_Mining", "AptitudeRemarkable_Intellectual",
            "AptitudeRemarkable_Crafting", "AptitudeRemarkable_Animals",
            "AptitudeStrong_Social"
        };

        private static readonly string[] PsychicGenes = new[]
        {
            "PsychicAbility_Enhanced", "PsychicAbility_Extreme", "PsychicBonding"
        };

        private static readonly string[] ResistanceGenes = new[]
        {
            "ToxicEnvironmentResistance_Total", "ToxResist_Total", "FireResistant",
            "AddictionImmune_WakeUp", "Immunity_SuperStrong",
            "PollutionRush"
        };

        private static readonly string[] SocialCosmeticGenes = new[]
        {
            "Beauty_Beautiful", "KindInstinct", "Mood_Sanguine", "Hair_Grayless",
            "Libido_High"
        };

        private static readonly string[] AnimalLikeGenes = new[]
        {
            "Furskin", "Tail_Furry", "Tail_Smooth", "FireSpew"
        };

        private static readonly string[] PainTemperatureGenes = new[]
        {
            "Pain_Reduced", "MaxTemp_SmallIncrease", "MinTemp_SmallDecrease",
            "MaxTemp_LargeIncrease", "MinTemp_SmallIncrease"
        };

        private static readonly string[] SanguophageGenes = new[]
        {
            "Hemogenic", "Bloodfeeder", "Coagulate", "LongjumpLegs", "PiercingSpine"
        };

        private static readonly string[] ArchiteGenes = new[]
        {
            "Ageless", "Deathless", "ArchiteMetabolism", "XenogermReimplanter"
        };

        // All OP genes combined
        private static readonly string[] OpGenes = HealingGenes
            .Concat(CombatGenes)
            .Concat(UtilityGenes)
            .Concat(PsychicGenes)
            .Concat(ResistanceGenes)
            .Concat(SocialCosmeticGenes)
            .Concat(AnimalLikeGenes)
            .Concat(PainTemperatureGenes)
            .Concat(SanguophageGenes)
            .Concat(ArchiteGenes)
            .Distinct()
            .ToArray();

        // Define conflicting gene groups with strength priority (higher number = stronger)
        private static readonly Dictionary<string, (string[] Group, int Priority)> GeneConflictGroups = new Dictionary<string, (string[] Group, int Priority)>
        {
            { "WoundHealing_Fast", (new[] { "WoundHealing_Fast", "WoundHealing_SuperFast" }, 1) },
            { "WoundHealing_SuperFast", (new[] { "WoundHealing_Fast", "WoundHealing_SuperFast" }, 2) },
            { "Immunity_Strong", (new[] { "Immunity_Strong", "Immunity_SuperStrong", "PerfectImmunity" }, 1) },
            { "Immunity_SuperStrong", (new[] { "Immunity_Strong", "Immunity_SuperStrong", "PerfectImmunity" }, 2) },
            { "PerfectImmunity", (new[] { "Immunity_Strong", "Immunity_SuperStrong", "PerfectImmunity" }, 3) },
            { "MoveSpeed_Quick", (new[] { "MoveSpeed_Quick", "MoveSpeed_VeryQuick" }, 1) },
            { "MoveSpeed_VeryQuick", (new[] { "MoveSpeed_Quick", "MoveSpeed_VeryQuick" }, 2) },
            { "PsychicAbility_Enhanced", (new[] { "PsychicAbility_Enhanced", "PsychicAbility_Extreme" }, 1) },
            { "PsychicAbility_Extreme", (new[] { "PsychicAbility_Enhanced", "PsychicAbility_Extreme" }, 2) },
            { "ToxicEnvironmentResistance_Partial", (new[] { "ToxicEnvironmentResistance_Partial", "ToxicEnvironmentResistance_Total" }, 1) },
            { "ToxicEnvironmentResistance_Total", (new[] { "ToxicEnvironmentResistance_Partial", "ToxicEnvironmentResistance_Total" }, 2) },
            { "Beauty_Pretty", (new[] { "Beauty_Pretty", "Beauty_Beautiful" }, 1) },
            { "Beauty_Beautiful", (new[] { "Beauty_Pretty", "Beauty_Beautiful" }, 2) },
            { "MaxTemp_SmallIncrease", (new[] { "MaxTemp_SmallIncrease", "MaxTemp_LargeIncrease" }, 1) },
            { "MaxTemp_LargeIncrease", (new[] { "MaxTemp_SmallIncrease", "MaxTemp_LargeIncrease" }, 2) },
            { "MinTemp_SmallDecrease", (new[] { "MinTemp_SmallDecrease", "MinTemp_SmallIncrease" }, 1) },
            { "MinTemp_SmallIncrease", (new[] { "MinTemp_SmallDecrease", "MinTemp_SmallIncrease" }, 2) }
        };

        // Main method to generate float menu options
        public static IEnumerable<FloatMenuOption> GetBioTechFloatMenuOptions(Pawn pawn)
        {
            List<FloatMenuOption> options = new List<FloatMenuOption>();

            // Ensure pawn has gene system
            if (pawn.genes == null)
            {
                Log.Warning($"[SuperColonyBuffs] BioTech: Pawn {pawn.Label} has no gene system. Cannot apply genes.");
                return options;
            }

            // Inject OP Genes
            options.Add(new FloatMenuOption("Inject OP Genes", () =>
            {
                ApplyGenes(pawn, OpGenes, "OP Enhanced " + pawn.LabelShort, true);
                Messages.Message($"{pawn.Label} has been enhanced with all OP genes.", MessageTypeDefOf.PositiveEvent);
            }));

            // Inject Category Genes (submenu)
            options.Add(new FloatMenuOption("Inject Category Genes", () =>
            {
                List<FloatMenuOption> categoryOptions = new List<FloatMenuOption>
                {
                    new FloatMenuOption("Healing", () =>
                    {
                        ApplyGenes(pawn, HealingGenes, "Healing Enhanced " + pawn.LabelShort, true);
                        Messages.Message($"{pawn.Label} has been enhanced with healing genes.", MessageTypeDefOf.PositiveEvent);
                    }),
                    new FloatMenuOption("Combat", () =>
                    {
                        ApplyGenes(pawn, CombatGenes, "Combat Enhanced " + pawn.LabelShort, true);
                        Messages.Message($"{pawn.Label} has been enhanced with combat genes.", MessageTypeDefOf.PositiveEvent);
                    }),
                    new FloatMenuOption("Utility", () =>
                    {
                        ApplyGenes(pawn, UtilityGenes, "Utility Enhanced " + pawn.LabelShort, true);
                        Messages.Message($"{pawn.Label} has been enhanced with utility genes.", MessageTypeDefOf.PositiveEvent);
                    }),
                    new FloatMenuOption("Psychic", () =>
                    {
                        ApplyGenes(pawn, PsychicGenes, "Psychic Enhanced " + pawn.LabelShort, true);
                        Messages.Message($"{pawn.Label} has been enhanced with psychic genes.", MessageTypeDefOf.PositiveEvent);
                    }),
                    new FloatMenuOption("Resistance", () =>
                    {
                        ApplyGenes(pawn, ResistanceGenes, "Resistance Enhanced " + pawn.LabelShort, true);
                        Messages.Message($"{pawn.Label} has been enhanced with resistance genes.", MessageTypeDefOf.PositiveEvent);
                    }),
                    new FloatMenuOption("Social/Cosmetic", () =>
                    {
                        ApplyGenes(pawn, SocialCosmeticGenes, "Social Enhanced " + pawn.LabelShort, true);
                        Messages.Message($"{pawn.Label} has been enhanced with social and cosmetic genes.", MessageTypeDefOf.PositiveEvent);
                    }),
                    new FloatMenuOption("AnimalLike", () =>
                    {
                        ApplyGenes(pawn, AnimalLikeGenes, "AnimalLike Enhanced " + pawn.LabelShort, true);
                        Messages.Message($"{pawn.Label} has been enhanced with animal-like genes.", MessageTypeDefOf.PositiveEvent);
                    }),
                    new FloatMenuOption("Pain/Temperature", () =>
                    {
                        ApplyGenes(pawn, PainTemperatureGenes, "Pain/Temp Enhanced " + pawn.LabelShort, true);
                        Messages.Message($"{pawn.Label} has been enhanced with pain and temperature genes.", MessageTypeDefOf.PositiveEvent);
                    }),
                    new FloatMenuOption("Sanguophage", () =>
                    {
                        ApplyGenes(pawn, SanguophageGenes, "Sanguophage Enhanced " + pawn.LabelShort, true);
                        Messages.Message($"{pawn.Label} has been enhanced with sanguophage genes.", MessageTypeDefOf.PositiveEvent);
                    }),
                    new FloatMenuOption("Archite", () =>
                    {
                        ApplyGenes(pawn, ArchiteGenes, "Archite Enhanced " + pawn.LabelShort, true);
                        Messages.Message($"{pawn.Label} has been enhanced with archite genes.", MessageTypeDefOf.PositiveEvent);
                    })
                };

                FloatMenu subMenu = new FloatMenu(categoryOptions);
                Find.WindowStack.Add(subMenu);
            }));

            // Wipe Genes
            options.Add(new FloatMenuOption("Wipe Genes", () =>
            {
                List<Gene> genesToRemove = pawn.genes.Endogenes.Concat(pawn.genes.Xenogenes).ToList();
                foreach (var gene in genesToRemove)
                {
                    pawn.genes.RemoveGene(gene);
                }
                XenotypeDef baseliner = DefDatabase<XenotypeDef>.GetNamed("Baseliner");
                pawn.genes.SetXenotype(baseliner);
                Messages.Message($"{pawn.Label}'s genes have been wiped. Reverted to Baseliner xenotype.", MessageTypeDefOf.NeutralEvent);
            }));

            return options;
        }

        // Helper method to get the strongest gene in a conflicting group
        private static GeneDef GetStrongestGeneInGroup(GeneDef newGene, List<GeneDef> existingGenes)
        {
            if (!GeneConflictGroups.ContainsKey(newGene.defName))
                return newGene;

            var (group, newPriority) = GeneConflictGroups[newGene.defName];
            GeneDef strongestGene = newGene;
            int highestPriority = newPriority;

            foreach (var existingGene in existingGenes)
            {
                if (GeneConflictGroups.ContainsKey(existingGene.defName))
                {
                    var (existingGroup, existingPriority) = GeneConflictGroups[existingGene.defName];
                    if (group.SequenceEqual(existingGroup) && existingPriority > highestPriority)
                    {
                        strongestGene = existingGene;
                        highestPriority = existingPriority;
                    }
                }
            }

            return strongestGene;
        }

        // Helper method to apply genes and create/update custom xenotype
        private static void ApplyGenes(Pawn pawn, string[] geneDefNames, string xenotypeLabel, bool keepExistingGenes)
        {
            Log.Message("[SuperColonyBuffs] BioTech: Listing all available GeneDefs before applying...");
            foreach (var geneDef in DefDatabase<GeneDef>.AllDefsListForReading)
            {
                Log.Message($"[SuperColonyBuffs] BioTech: Found GeneDef: {geneDef.defName}");
            }
            Log.Message("[SuperColonyBuffs] BioTech: Finished listing GeneDefs.");

            List<GeneDef> genesToAdd = new List<GeneDef>();
            foreach (string geneDefName in geneDefNames)
            {
                try
                {
                    GeneDef geneDef = DefDatabase<GeneDef>.GetNamed(geneDefName, false);
                    if (geneDef == null)
                    {
                        Log.Warning($"[SuperColonyBuffs] BioTech: Could not find GeneDef {geneDefName}");
                        continue;
                    }
                    genesToAdd.Add(geneDef);
                }
                catch (System.Exception ex)
                {
                    Log.Error($"[SuperColonyBuffs] BioTech: Failed to find GeneDef {geneDefName}. Error: {ex.Message}");
                }
            }

            if (genesToAdd.Count > 0)
            {
                List<GeneDef> currentGenes = new List<GeneDef>();
                if (keepExistingGenes && pawn.genes.Xenogenes != null)
                {
                    currentGenes.AddRange(pawn.genes.Xenogenes.Select(g => g.def));
                }

                // Filter genes to ensure only the strongest in each conflicting group is added
                List<GeneDef> filteredGenesToAdd = new List<GeneDef>();
                foreach (var newGene in genesToAdd)
                {
                    if (pawn.genes.HasActiveGene(newGene))
                    {
                        Log.Message($"[SuperColonyBuffs] BioTech: Pawn {pawn.Label} already has active GeneDef {newGene.defName}. Skipping.");
                        continue;
                    }

                    GeneDef strongestGene = GetStrongestGeneInGroup(newGene, currentGenes);
                    if (strongestGene != newGene)
                    {
                        Log.Message($"[SuperColonyBuffs] BioTech: Skipping {newGene.defName} as {strongestGene.defName} is stronger.");
                        continue;
                    }

                    // Remove weaker conflicting genes
                    if (GeneConflictGroups.ContainsKey(newGene.defName))
                    {
                        var (group, _) = GeneConflictGroups[newGene.defName];
                        foreach (var geneToRemove in pawn.genes.Xenogenes.ToList())
                        {
                            if (group.Contains(geneToRemove.def.defName) && geneToRemove.def != newGene)
                            {
                                pawn.genes.RemoveGene(geneToRemove);
                                Log.Message($"[SuperColonyBuffs] BioTech: Removed conflicting gene {geneToRemove.def.defName} to apply {newGene.defName}.");
                            }
                        }
                    }

                    filteredGenesToAdd.Add(newGene);
                }

                List<GeneDef> allGenesToApply = currentGenes.Concat(filteredGenesToAdd).Distinct().ToList();

                // Create custom xenotype
                CustomXenotype customXenotype = new CustomXenotype
                {
                    defName = "SuperColonyBuffs_CustomXenotype_" + pawn.ThingID,
                    label = xenotypeLabel,
                    genes = allGenesToApply,
                    inheritable = false
                };

                XenotypeDef xenotypeDef = new XenotypeDef
                {
                    defName = customXenotype.defName,
                    label = customXenotype.label,
                    genes = customXenotype.genes,
                    inheritable = customXenotype.inheritable
                };

                DefDatabase<XenotypeDef>.Add(xenotypeDef);
                pawn.genes.SetXenotype(xenotypeDef);

                // Actually add the genes to the pawn
                foreach (var geneDef in filteredGenesToAdd)
                {
                    pawn.genes.AddGene(geneDef, true);
                    Log.Message($"[SuperColonyBuffs] BioTech: Successfully applied GeneDef {geneDef.defName} to {pawn.Label}");
                }
            }
            else if (!keepExistingGenes)
            {
                XenotypeDef baseliner = DefDatabase<XenotypeDef>.GetNamed("Baseliner");
                pawn.genes.SetXenotype(baseliner);
                Log.Warning($"[SuperColonyBuffs] BioTech: No new genes were found to apply to {pawn.Label} and 'keepExistingGenes' was false. Reverted to Baseliner xenotype.");
            }
            else
            {
                Log.Warning($"[SuperColonyBuffs] BioTech: No new genes were found to apply to {pawn.Label}. Existing genes were kept.");
            }
        }

        public static void ApplyMaxPsylink(Pawn pawn)
        {
            if (pawn.psychicEntropy == null)
            {
                Log.Warning($"[SuperColonyBuffs] BioTech: Pawn {pawn.Label} has no psychic entropy system. Cannot apply psylink.");
                return;
            }

            HediffDef psylinkDef = DefDatabase<HediffDef>.GetNamed("PsychicAmplifier", false);
            if (psylinkDef == null)
            {
                Log.Warning("[SuperColonyBuffs] BioTech: Could not find HediffDef PsychicAmplifier");
                return;
            }

            Hediff existingPsylink = pawn.health.hediffSet.GetFirstHediffOfDef(psylinkDef);
            if (existingPsylink != null)
            {
                pawn.health.RemoveHediff(existingPsylink);
            }

            Hediff psylinkHediff = HediffMaker.MakeHediff(psylinkDef, pawn, pawn.health.hediffSet.GetBrain());
            psylinkHediff.Severity = 6;
            pawn.health.AddHediff(psylinkHediff, pawn.health.hediffSet.GetBrain());

            if (pawn.abilities != null)
            {
                foreach (AbilityDef abilityDef in DefDatabase<AbilityDef>.AllDefsListForReading
                    .Where(def => def.level <= 6))
                {
                    if (!pawn.abilities.abilities.Any(a => a.def == abilityDef))
                    {
                        pawn.abilities.GainAbility(abilityDef);
                    }
                }
            }

            if (pawn.genes != null && pawn.genes.HasActiveGene(DefDatabase<GeneDef>.GetNamed("PsychicBonding", false)))
            {
                HediffDef sensitivityHediff = DefDatabase<HediffDef>.GetNamed("PsychicSensitivity", false);
                if (sensitivityHediff != null)
                {
                    Hediff sensitivity = pawn.health.hediffSet.GetFirstHediffOfDef(sensitivityHediff);
                    if (sensitivity != null)
                    {
                        sensitivity.Severity = 1.5f;
                    }
                    else
                    {
                        sensitivity = HediffMaker.MakeHediff(sensitivityHediff, pawn);
                        sensitivity.Severity = 1.5f;
                        pawn.health.AddHediff(sensitivity);
                    }
                }
                else
                {
                    Log.Warning("[SuperColonyBuffs] BioTech: Could not find HediffDef PsychicSensitivity to boost sensitivity.");
                }
            }

            Messages.Message($"{pawn.Label} has been granted maximum psylink level.", MessageTypeDefOf.PositiveEvent);
        }

        private class CustomXenotype
        {
            public string defName;
            public string label;
            public List<GeneDef> genes;
            public bool inheritable;
        }
    }
}