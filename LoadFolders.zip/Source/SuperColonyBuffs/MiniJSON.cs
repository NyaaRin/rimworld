// Minimal JSON parser/serializer for Unity (public domain)
// Source adapted from https://gist.github.com/darktable/1411710
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

namespace SuperColonyBuffs
{
    internal static class MiniJSON
    {
        public static object Deserialize(string json)
        {
            if (json == null) return null;
            return Parser.Parse(json);
        }

        public static string Serialize(object obj)
        {
            return Serializer.Serialize(obj);
        }

        private sealed class Parser : System.IDisposable
        {
            private const string WORD_BREAK = "{}[],:\"";
            private readonly string json;
            private int index;
            private Parser(string json)
            {
                this.json = json;
            }
            public static object Parse(string json)
            {
                using (var parser = new Parser(json))
                {
                    return parser.ParseValue();
                }
            }
            public void Dispose() { }
            private char PeekChar => index < json.Length ? json[index] : '\0';
            private char NextChar()
            {
                return index < json.Length ? json[index++] : '\0';
            }
            private string NextWord()
            {
                StringBuilder sb = new StringBuilder();
                while (index < json.Length && WORD_BREAK.IndexOf(json[index]) == -1 && !char.IsWhiteSpace(json[index]))
                    sb.Append(NextChar());
                return sb.ToString();
            }
            private void SkipWhitespace()
            {
                while (index < json.Length && char.IsWhiteSpace(PeekChar)) index++;
            }
            private object ParseValue()
            {
                SkipWhitespace();
                if (index == json.Length) return null;
                char ch = PeekChar;
                switch (ch)
                {
                    case '{': return ParseObject();
                    case '[': return ParseArray();
                    case '"': return ParseString();
                    case 't': NextWord(); return true;
                    case 'f': NextWord(); return false;
                    case 'n': NextWord(); return null;
                    default: return ParseNumber();
                }
            }
            private IDictionary<string, object> ParseObject()
            {
                Dictionary<string, object> obj = new Dictionary<string, object>();
                NextChar(); // {
                for (;;)
                {
                    SkipWhitespace();
                    if (PeekChar == '}') { NextChar(); break; }
                    string key = ParseString();
                    SkipWhitespace();
                    NextChar(); // :
                    object value = ParseValue();
                    obj[key] = value;
                    SkipWhitespace();
                    if (PeekChar == ',') { NextChar(); continue; }
                    if (PeekChar == '}') { NextChar(); break; }
                }
                return obj;
            }
            private IList ParseArray()
            {
                List<object> list = new List<object>();
                NextChar(); // [
                for (;;)
                {
                    SkipWhitespace();
                    if (PeekChar == ']') { NextChar(); break; }
                    list.Add(ParseValue());
                    SkipWhitespace();
                    if (PeekChar == ',') { NextChar(); continue; }
                    if (PeekChar == ']') { NextChar(); break; }
                }
                return list;
            }
            private string ParseString()
            {
                StringBuilder sb = new StringBuilder();
                NextChar(); // "
                while (index < json.Length)
                {
                    char ch = NextChar();
                    if (ch == '"') break;
                    if (ch == '\\')
                    {
                        if (index == json.Length) break;
                        ch = NextChar();
                        switch (ch)
                        {
                            case '"': sb.Append('"'); break;
                            case '\\': sb.Append('\\'); break;
                            case '/': sb.Append('/'); break;
                            case 'b': sb.Append('\b'); break;
                            case 'f': sb.Append('\f'); break;
                            case 'n': sb.Append('\n'); break;
                            case 'r': sb.Append('\r'); break;
                            case 't': sb.Append('\t'); break;
                            case 'u':
                                string hex = new string(new[] { NextChar(), NextChar(), NextChar(), NextChar() });
                                sb.Append((char)int.Parse(hex, NumberStyles.HexNumber));
                                break;
                        }
                    }
                    else sb.Append(ch);
                }
                return sb.ToString();
            }
            private object ParseNumber()
            {
                string number = NextWord();
                if (number.IndexOf('.') != -1 || number.IndexOf('e') != -1 || number.IndexOf('E') != -1)
                {
                    if (double.TryParse(number, NumberStyles.Any, CultureInfo.InvariantCulture, out var valD)) return valD;
                }
                else
                {
                    if (long.TryParse(number, NumberStyles.Any, CultureInfo.InvariantCulture, out var valL)) return valL;
                }
                return 0;
            }
        }

        private sealed class Serializer
        {
            private StringBuilder sb;
            private Serializer() { sb = new StringBuilder(); }
            public static string Serialize(object obj)
            {
                var instance = new Serializer();
                instance.SerializeValue(obj);
                return instance.sb.ToString();
            }
            private void SerializeValue(object value)
            {
                if (value == null) { sb.Append("null"); return; }
                if (value is string s) { SerializeString(s); return; }
                if (value is bool b) { sb.Append(b ? "true" : "false"); return; }
                if (value is IList list) { SerializeArray(list); return; }
                if (value is IDictionary dict) { SerializeObject(dict); return; }
                if (value is char c) { SerializeString(c.ToString()); return; }
                SerializeString(System.Convert.ToString(value, CultureInfo.InvariantCulture));
            }
            private void SerializeObject(IDictionary obj)
            {
                bool first = true;
                sb.Append('{');
                foreach (object e in obj.Keys)
                {
                    if (!first) sb.Append(',');
                    SerializeString(e.ToString());
                    sb.Append(':');
                    SerializeValue(obj[e]);
                    first = false;
                }
                sb.Append('}');
            }
            private void SerializeArray(IList array)
            {
                sb.Append('[');
                bool first = true;
                foreach (var v in array)
                {
                    if (!first) sb.Append(',');
                    SerializeValue(v);
                    first = false;
                }
                sb.Append(']');
            }
            private void SerializeString(string str)
            {
                sb.Append('"');
                foreach (char ch in str)
                {
                    switch (ch)
                    {
                        case '"': sb.Append("\\\""); break;
                        case '\\': sb.Append("\\\\"); break;
                        case '\b': sb.Append("\\b"); break;
                        case '\f': sb.Append("\\f"); break;
                        case '\n': sb.Append("\\n"); break;
                        case '\r': sb.Append("\\r"); break;
                        case '\t': sb.Append("\\t"); break;
                        default: sb.Append(ch); break;
                    }
                }
                sb.Append('"');
            }
        }
    }
} 