﻿using RimWorld;
using Verse;

namespace SuperColonyBuffs
{
    public class NoSlaveRebellionWorker : IncidentWorker
    {
        protected override bool CanFireNowSub(IncidentParms parms)
        {
            // Prevent slave rebellions by always returning false
            return false;
        }

        protected override bool TryExecuteWorker(IncidentParms parms)
        {
            // Should never be called due to CanFireNowSub returning false
            return false;
        }
    }
}