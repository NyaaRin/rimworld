using System;
using System.Collections.Generic;
using Verse;
using System.IO;
using System.Text;
using System.Linq;
using UnityEngine;
using Newtonsoft.Json;

namespace SuperColonyBuffs
{
    [Serializable]
    public class LoadoutData
    {
        public string Name = "New Loadout";
        public string Helmet;
        public List<string> Apparel = new List<string>();
        public string PrimaryWeapon;
        public string SecondaryWeapon;
        public List<string> Medkits = new List<string>();
        public List<string> Extra = new List<string>();
        public Dictionary<string, int> Ammo = new Dictionary<string, int>();
        public Dictionary<string, string> ItemMaterials = new Dictionary<string, string>(); // key: item defName, value: material defName

        public LoadoutData()
        {
            Apparel = new List<string>();
            Medkits = new List<string>();
            Extra = new List<string>();
            Ammo = new Dictionary<string, int>();
            ItemMaterials = new Dictionary<string, string>();
        }

        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"Name: {Name}");
            sb.AppendLine($"Helmet: {Helmet}");
            sb.AppendLine("Apparel:");
            foreach (var item in Apparel)
            {
                sb.AppendLine($"  - {item}");
            }
            sb.AppendLine($"PrimaryWeapon: {PrimaryWeapon}");
            sb.AppendLine($"SecondaryWeapon: {SecondaryWeapon}");
            sb.AppendLine("Medkits:");
            foreach (var item in Medkits)
            {
                sb.AppendLine($"  - {item}");
            }
            sb.AppendLine("Extra:");
            foreach (var item in Extra)
            {
                sb.AppendLine($"  - {item}");
            }
            sb.AppendLine("Ammo:");
            foreach (var item in Ammo)
            {
                sb.AppendLine($"  - {item.Key}: {item.Value}");
            }
            return sb.ToString();
        }
    }

    [Serializable]
    public class LoadoutDataWrapper
    {
        public List<LoadoutData> loadouts = new List<LoadoutData>();
    }

    // Bridge class to call UnityEngine.JsonUtility via reflection at runtime while allowing compilation without UnityEngine assemblies
    internal static class JsonUtilityBridge
    {
        private static readonly System.Reflection.MethodInfo toJsonMethod;
        private static readonly System.Reflection.MethodInfo fromJsonMethod;

        static JsonUtilityBridge()
        {
            var jsonType = Type.GetType("UnityEngine.JsonUtility, UnityEngine.CoreModule") ??
                           Type.GetType("UnityEngine.JsonUtility, UnityEngine") ??
                           Type.GetType("UnityEngine.JsonUtility, UnityEngine.JSONSerializeModule");

            if (jsonType == null)
            {
                // As a last resort, scan loaded assemblies (handles cases where the module name is different).
                foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
                {
                    jsonType = asm.GetType("UnityEngine.JsonUtility");
                    if (jsonType != null) break;
                }
            }

            if (jsonType != null)
            {
                toJsonMethod = jsonType.GetMethod("ToJson", new[] { typeof(object), typeof(bool) });
                fromJsonMethod = jsonType.GetMethods(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static)
                                          .FirstOrDefault(m => m.Name == "FromJson" && m.IsGenericMethodDefinition && m.GetParameters().Length == 1);
            }
        }

        public static string ToJson(object obj, bool prettyPrint)
        {
            if (toJsonMethod != null)
                return (string)toJsonMethod.Invoke(null, new[] { obj, (object)prettyPrint });
            return string.Empty;
        }

        public static T FromJson<T>(string json)
        {
            if (fromJsonMethod != null)
            {
                var generic = fromJsonMethod.MakeGenericMethod(typeof(T));
                return (T)generic.Invoke(null, new object[] { json });
            }
            return default(T);
        }
    }

    public static class LoadoutManager
    {
        private static List<LoadoutData> loadouts = new List<LoadoutData>();
        private static string LoadoutsPath => Path.Combine(GenFilePaths.ModsFolderPath, "Izumis World", "Loadouts", "Loadouts.txt");
        private static bool isInitialized = false;
        private static DateTime lastLoadTime = DateTime.MinValue;
        private static readonly TimeSpan RefreshInterval = TimeSpan.FromSeconds(60);

        public static void Initialize()
        {
            Log.Message("[SuperColonyBuffs] Initializing loadouts...");
            if (isInitialized)
            {
                Log.Message("[SuperColonyBuffs] Loadouts already initialized");
                return;
            }
            try
            {
                LoadLoadouts();
                isInitialized = true;
                Log.Message("[SuperColonyBuffs] Loadouts initialization complete");
            }
            catch (Exception ex)
            {
                Log.Error($"[SuperColonyBuffs] Failed to initialize loadouts: {ex.Message}\nStack trace: {ex.StackTrace}");
                loadouts = new List<LoadoutData>();
                isInitialized = true;
            }
        }

        private static void LoadLoadouts()
        {
            try
            {
                Log.Message($"[SuperColonyBuffs] Attempting to load loadouts from: {LoadoutsPath}");
                if (!File.Exists(LoadoutsPath))
                {
                    Log.Error($"[SuperColonyBuffs] Loadouts file not found at path: {LoadoutsPath}");
                    loadouts = new List<LoadoutData>();
                    return;
                }

                var lines = File.ReadAllLines(LoadoutsPath);
                var list = new List<LoadoutData>();
                foreach (var line in lines)
                {
                    if (string.IsNullOrWhiteSpace(line)) continue;
                    var parts = line.Split('|');
                    if (parts.Length < 8) continue; // skip malformed lines
                    var ld = new LoadoutData();
                    ld.Name = parts[0];
                    ld.Helmet = parts[1];
                    ld.Apparel = parts[2].Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList();
                    ld.PrimaryWeapon = parts[3];
                    ld.SecondaryWeapon = parts[4];
                    ld.Medkits = parts[5].Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList();
                    ld.Extra = parts[6].Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList();
                    ld.Ammo = new Dictionary<string, int>();
                    foreach (var ammoPair in parts[7].Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        var kv = ammoPair.Split(':');
                        if (kv.Length == 2 && int.TryParse(kv[1], out int qty))
                            ld.Ammo[kv[0]] = qty;
                    }
                    list.Add(ld);
                }
                loadouts = list;
                Log.Message($"[SuperColonyBuffs] Successfully loaded {loadouts.Count} loadouts from text file");
            }
            catch (Exception ex)
            {
                Log.Error($"[SuperColonyBuffs] Failed to load loadouts: {ex.Message}\nStack trace: {ex.StackTrace}");
                loadouts = new List<LoadoutData>();
            }
            finally
            {
                lastLoadTime = DateTime.Now;
            }
        }

        public static List<LoadoutData> GetLoadouts()
        {
            Log.Message("[SuperColonyBuffs] GetLoadouts called");
            if (!isInitialized)
            {
                Log.Message("[SuperColonyBuffs] Loadouts not initialized, initializing now...");
                Initialize();
            }
            else if ((DateTime.Now - lastLoadTime) > RefreshInterval)
            {
                Log.Message($"[SuperColonyBuffs] Refresh interval passed (>{RefreshInterval.TotalSeconds}s); reloading loadouts");
                LoadLoadouts();
            }
            var result = loadouts ?? new List<LoadoutData>();
            Log.Message($"[SuperColonyBuffs] Returning {result.Count} loadouts");
            return result;
        }

        private static void CreateDefaultLoadouts()
        {
            if (loadouts == null)
            {
                loadouts = new List<LoadoutData>();
            }
            if (loadouts.Count == 0)
            {
                loadouts.Add(new LoadoutData
                {
                    Name = "Basic Loadout",
                    Helmet = "Apparel_HelmetBasic",
                    Apparel = new List<string> { "Apparel_FlakJacket", "Apparel_FlakPants" },
                    PrimaryWeapon = "Gun_Revolver",
                    SecondaryWeapon = "MeleeWeapon_Knife",
                    Medkits = new List<string> { "MedicineHerbal" },
                    Extra = new List<string>(),
                    Ammo = new Dictionary<string, int> { { "Ammo_9mm", 1000 } }
                });
                SaveLoadouts();
            }
        }

        public static void SaveLoadouts()
        {
            try
            {
                Log.Message("[SuperColonyBuffs] Saving loadouts...");
                var directory = Path.GetDirectoryName(LoadoutsPath);
                if (!Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }
                var lines = new List<string>();
                foreach (var ld in loadouts)
                {
                    var apparel = string.Join(",", ld.Apparel ?? new List<string>());
                    var medkits = string.Join(",", ld.Medkits ?? new List<string>());
                    var extra = string.Join(",", ld.Extra ?? new List<string>());
                    var ammo = string.Join(",", (ld.Ammo ?? new Dictionary<string, int>()).Select(kv => $"{kv.Key}:{kv.Value}"));
                    var line = string.Join("|",
                        ld.Name ?? "",
                        ld.Helmet ?? "",
                        apparel,
                        ld.PrimaryWeapon ?? "",
                        ld.SecondaryWeapon ?? "",
                        medkits,
                        extra,
                        ammo
                    );
                    lines.Add(line);
                }
                File.WriteAllLines(LoadoutsPath, lines);
                Log.Message("[SuperColonyBuffs] Loadouts saved successfully to text file");
            }
            catch (Exception ex)
            {
                Log.Error($"[SuperColonyBuffs] Failed to save loadouts: {ex.Message}\nStack trace: {ex.StackTrace}");
            }
        }

        private static LoadoutData CreateRiotLoadout()
        {
            return new LoadoutData
            {
                Name = "Riot",
                Helmet = "Apparel_AdvancedHelmet",
                Apparel = new List<string>
                {
                    "Apparel_FlakJacket",
                    "Apparel_FlakPants",
                    "Apparel_FlakVest"
                },
                PrimaryWeapon = "RNGun_C8CQB_Carbine",
                SecondaryWeapon = "MeleeWeapon_MonoSword",
                Medkits = new List<string> { "MedicineUltratech" },
                Extra = new List<string>(),
                Ammo = new Dictionary<string, int>
                {
                    { "Ammo_556x45mmNATO_Sabot", 1000 }
                }
            };
        }

        private static LoadoutData CreateCataphractLoadout()
        {
            return new LoadoutData
            {
                Name = "Cataphract",
                Helmet = "Apparel_ArmorHelmetCataphractPrestige",
                Apparel = new List<string>
                {
                    "Apparel_ArmorCataphractPrestige"
                },
                PrimaryWeapon = "VWE_Gun_ChargeShotgun",
                SecondaryWeapon = "MeleeWeapon_MonoSword",
                Medkits = new List<string> { "MedicineUltratech" },
                Extra = new List<string>(),
                Ammo = new Dictionary<string, int>
                {
                    { "Ammo_12GaugeCharged_Ion", 1000 }
                }
            };
        }

        private static LoadoutData CreateRailGunPowerArmorLoadout()
        {
            return new LoadoutData
            {
                Name = "RailGunPowerArmor",
                Helmet = "Apparel_PowerArmorHelmet",
                Apparel = new List<string>
                {
                    "Apparel_PowerArmor"
                },
                PrimaryWeapon = "Gun_RailgunSW",
                SecondaryWeapon = "VFEE_MeleeWeapon_ToxbladeBladelink",
                Medkits = new List<string> { "MedicineUltratech" },
                Extra = new List<string>
                {
                    "Gun_HellsphereCannon"
                }
            };
        }

        private static LoadoutData CreateGaussPowerArmorLoadout()
        {
            return new LoadoutData
            {
                Name = "GaussPowerArmor",
                Helmet = "Apparel_PowerArmorHelmet",
                Apparel = new List<string>
                {
                    "Apparel_PowerArmor"
                },
                PrimaryWeapon = "Gun_GaussrifleSW",
                SecondaryWeapon = "MeleeWeapon_MonoSwordBladelink",
                Medkits = new List<string> { "MedicineUltratech" },
                Extra = new List<string>
                {
                    "Gun_DoomsdayRocket"
                }
            };
        }

        private static LoadoutData CreatePowerArmorLoadout()
        {
            return new LoadoutData
            {
                Name = "PowerArmor",
                Helmet = "Apparel_PowerArmorHelmet",
                Apparel = new List<string>
                {
                    "Apparel_PowerArmor"
                },
                PrimaryWeapon = "CE_MechanoidMinigun",
                SecondaryWeapon = "MeleeWeapon_MonoSword",
                Medkits = new List<string> { "MedicineUltratech" },
                Extra = new List<string>
                {
                    "Gun_DoomsdayRocket"
                },
                Ammo = new Dictionary<string, int>
                {
                    { "Ammo_762x51mmNATO_HE", 1000 }
                }
            };
        }

        private static LoadoutData ParseLoadoutFromDict(Dictionary<string, object> dict)
        {
            var ld = new LoadoutData();
            if (dict.TryGetValue("Name", out var n)) ld.Name = n as string;
            if (dict.TryGetValue("Helmet", out var h)) ld.Helmet = h as string;
            if (dict.TryGetValue("Apparel", out var ap) && ap is List<object> apList)
                ld.Apparel = apList.ConvertAll(o => o.ToString());
            if (dict.TryGetValue("PrimaryWeapon", out var pw)) ld.PrimaryWeapon = pw as string;
            if (dict.TryGetValue("SecondaryWeapon", out var sw)) ld.SecondaryWeapon = sw as string;
            if (dict.TryGetValue("Medkits", out var mk) && mk is List<object> mkList)
                ld.Medkits = mkList.ConvertAll(o => o.ToString());
            if (dict.TryGetValue("Extra", out var ex) && ex is List<object> exList)
                ld.Extra = exList.ConvertAll(o => o.ToString());
            if (dict.TryGetValue("Ammo", out var am) && am is Dictionary<string, object> amDict)
            {
                foreach (var kv in amDict)
                {
                    if (int.TryParse(kv.Value.ToString(), out int qty))
                        ld.Ammo[kv.Key] = qty;
                }
            }
            return ld;
        }

        // Helper to convert LoadoutData -> Dictionary for MiniJSON serialization
        private static Dictionary<string, object> LoadoutToDict(LoadoutData ld)
        {
            var dict = new Dictionary<string, object>
            {
                ["Name"] = ld.Name,
                ["Helmet"] = ld.Helmet,
                ["Apparel"] = new List<string>(ld.Apparel),
                ["PrimaryWeapon"] = ld.PrimaryWeapon,
                ["SecondaryWeapon"] = ld.SecondaryWeapon,
                ["Medkits"] = new List<string>(ld.Medkits),
                ["Extra"] = new List<string>(ld.Extra),
                ["Ammo"] = new Dictionary<string, object>()
            };

            var ammoDict = (Dictionary<string, object>)dict["Ammo"];
            foreach (var kv in ld.Ammo)
            {
                ammoDict[kv.Key] = kv.Value;
            }

            return dict;
        }
    }
} 