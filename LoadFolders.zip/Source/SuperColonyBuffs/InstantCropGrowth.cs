﻿using Verse;
using RimWorld;

namespace SuperColonyBuffs
{
    public static class SuperColonyBuffsManager
    {
        public static void Update(Map map)
        {
            if (map == null) return;

            // Instant Crop Growth
            if (ModSettings.instantCropGrowth)
            {
                foreach (Plant plant in map.listerThings.ThingsInGroup(ThingRequestGroup.Plant))
                {
                    if (plant != null && !plant.Destroyed && plant.def.plant != null &&
                        (plant.def.plant.sowTags.Contains("Standard") || plant.def.plant.sowTags.Contains("Hydroponics")) &&
                        plant.def.plant.harvestYield > 0f)
                    {
                        plant.Growth = 1f; // Set growth to 100%
                        if (ModSettings.debugMode)
                        {
                            Log.Message($"[SuperColonyBuffs] Set growth to 1.0 for plant: {plant.def.defName} at {plant.Position}");
                            Log.Message("N + L Forever, Until Death Do Us Part https://buymeacoffee.com/izumiontop");
                        }
                    }
                }
            }
        }
    }
}
