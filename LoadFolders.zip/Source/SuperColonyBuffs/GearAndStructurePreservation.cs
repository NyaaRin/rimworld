﻿using HarmonyLib;
using Verse;
using RimWorld;
using static Verse.DamageWorker;

namespace SuperColonyBuffs
{
    [HarmonyPatch(typeof(Thing), nameof(Thing.TakeDamage))]
    public static class Patch_Thing_TakeDamage
    {
        static bool Prefix(Thing __instance, DamageInfo dinfo, out DamageResult __result)
        {
            // Initialize the result
            __result = new DamageResult();

            // Handle gear preservation (apparel and weapons)
            if (ModSettings.preserveGear && (__instance is Apparel || (__instance is ThingWithComps thingWithComps && thingWithComps.def.IsWeapon)))
            {
                // Check if the thing is equipped by a pawn
                Pawn wearer = (__instance as Apparel)?.Wearer ?? (__instance.ParentHolder as Pawn_EquipmentTracker)?.pawn;
                if (wearer != null)
                {
                    bool applyPreservation = wearer.IsColonist ||
                                            (wearer.IsPrisoner && ModSettings.applyToPrisoners) ||
                                            (wearer.IsSlave && ModSettings.applyToSlaves);

                    if (applyPreservation)
                    {
                        // Prevent all damage to gear for qualifying pawns
                        return false; // Skip the original method
                    }
                }
            }

            // Handle structure preservation (for deterioration and combat damage)
            if (ModSettings.preserveStructures && __instance is Building building && building.Faction == Faction.OfPlayer)
            {
                // Check for deterioration or combat-related damage (bullets and melee)
                if (dinfo.Def == DamageDefOf.Deterioration ||
                    dinfo.Def == DamageDefOf.Bullet ||
                    dinfo.Def == DamageDefOf.Blunt ||
                    dinfo.Def == DamageDefOf.Stab ||
                    dinfo.Def == DamageDefOf.Cut ||
                    dinfo.Def == DamageDefOf.Crush ||
                    dinfo.Def == DamageDefOf.Scratch)
                {
                    // Prevent damage to player-owned buildings
                    return false; // Skip the original method
                }
            }

            // Allow the original method to handle all other cases
            return true;
        }
    }
}
