﻿using RimWorld;
using Verse;
using System.Collections.Generic;
using System.Linq;

namespace SuperColonyBuffs.BioTech
{
    public static class PsionicBuffs
    {
        // Method to generate float menu options for psionic enhancements
        public static IEnumerable<FloatMenuOption> GetPsionicFloatMenuOptions(Pawn pawn)
        {
            List<FloatMenuOption> options = new List<FloatMenuOption>();

            if (pawn.psychicEntropy == null)
            {
                Log.Warning($"[SuperColonyBuffs] Psionic: Pawn {pawn.Label} has no psychic entropy system. Cannot apply enhancements.");
                return options;
            }

            options.Add(new FloatMenuOption("Psionic Enhancements", () =>
            {
                ApplyPsionicEnhancements(pawn, "Psionic");
            }));
            options.Add(new FloatMenuOption("Shadow Enhancements", () =>
            {
                ApplyPsionicEnhancements(pawn, "Shadow");
            }));
            options.Add(new FloatMenuOption("Necro Enhancements", () =>
            {
                ApplyPsionicEnhancements(pawn, "Necro");
            }));
            options.Add(new FloatMenuOption("Arcane Enhancements", () =>
            {
                ApplyPsionicEnhancements(pawn, "Arcane");
            }));

            return options;
        }

        public static void ApplyPsionicEnhancements(Pawn pawn, string enhancementType)
        {
            if (pawn.psychicEntropy == null)
            {
                Log.Warning($"[SuperColonyBuffs] {enhancementType}: Pawn {pawn.Label} has no psychic entropy system. Cannot apply enhancements.");
                return;
            }

            // Set the class based on enhancement type (workaround since TM_ClassUtility is unavailable)
            switch (enhancementType)
            {
                case "Psionic":
                    ApplyBaseBuffs(pawn);
                    ApplyAllPsionicAbilities(pawn);
                    Messages.Message($"{pawn.Label} has been enhanced with Psionic powers.", MessageTypeDefOf.PositiveEvent);
                    break;
                case "Shadow":
                    ApplyBaseBuffs(pawn);
                    ApplyAllShadowAbilities(pawn);
                    Messages.Message($"{pawn.Label} has been enhanced with Shadow powers.", MessageTypeDefOf.PositiveEvent);
                    break;
                case "Necro":
                    ApplyBaseBuffs(pawn);
                    ApplyNecroBuffs(pawn);
                    ApplyAllNecromancerAbilities(pawn);
                    Messages.Message($"{pawn.Label} has been enhanced with Necromancer powers.", MessageTypeDefOf.PositiveEvent);
                    break;
                case "Arcane":
                    ApplyBaseBuffs(pawn);
                    ApplyArcaneBuffs(pawn);
                    Messages.Message($"{pawn.Label} has been enhanced with Arcane powers.", MessageTypeDefOf.PositiveEvent);
                    break;
            }

            // Apply TM_Gifted trait as part of enhancement
            ApplyTMGiftedTrait(pawn);
        }

        private static void ApplyBaseBuffs(Pawn pawn)
        {
            try
            {
                HediffDef psionicEnergyDef = DefDatabase<HediffDef>.GetNamed("TM_PsionicHD", false);
                if (psionicEnergyDef != null)
                {
                    Hediff psionicEnergy = HediffMaker.MakeHediff(psionicEnergyDef, pawn);
                    psionicEnergy.Severity = 0.5f;
                    pawn.health.AddHediff(psionicEnergy);
                    Log.Message($"[SuperColonyBuffs] Psionic: Applied TM_PsionicHD to {pawn.Label}");
                }

                HediffDef psionicSpeedDef = DefDatabase<HediffDef>.GetNamed("TM_PsionicSpeedHD_III", false);
                if (psionicSpeedDef != null)
                {
                    Hediff psionicSpeed = HediffMaker.MakeHediff(psionicSpeedDef, pawn);
                    psionicSpeed.Severity = 0.001f;
                    pawn.health.AddHediff(psionicSpeed);
                    Log.Message($"[SuperColonyBuffs] Psionic: Applied TM_PsionicSpeedHD_III to {pawn.Label}");
                }

                HediffDef psionicManipulationDefCustom = DefDatabase<HediffDef>.GetNamed("TM_PsionicManipulationHD_III", false);
                if (psionicManipulationDefCustom != null)
                {
                    Hediff psionicManipulation = HediffMaker.MakeHediff(psionicManipulationDefCustom, pawn);
                    psionicManipulation.Severity = 0.001f;
                    pawn.health.AddHediff(psionicManipulation);
                    Log.Message($"[SuperColonyBuffs] Psionic: Applied TM_PsionicManipulationHD_III to {pawn.Label}");
                }

                HediffDef ampDef = DefDatabase<HediffDef>.GetNamed("AMP_III", false);
                if (ampDef != null)
                {
                    Hediff ampBuff = HediffMaker.MakeHediff(ampDef, pawn);
                    ampBuff.Severity = 0.001f;
                    pawn.health.AddHediff(ampBuff);
                    Log.Message($"[SuperColonyBuffs] Psionic: Applied AMP_III to {pawn.Label}");
                }

                HediffDef rayOfHopeDef = DefDatabase<HediffDef>.GetNamed("RayofHope_III", false);
                if (rayOfHopeDef != null)
                {
                    Hediff rayOfHope = HediffMaker.MakeHediff(rayOfHopeDef, pawn);
                    rayOfHope.Severity = 0.001f;
                    pawn.health.AddHediff(rayOfHope);
                    Log.Message($"[SuperColonyBuffs] Psionic: Applied RayofHope_III to {pawn.Label}");
                }

                HediffDef shadowDef = DefDatabase<HediffDef>.GetNamed("Shadow_III", false);
                if (shadowDef != null)
                {
                    Hediff shadow = HediffMaker.MakeHediff(shadowDef, pawn);
                    shadow.Severity = 0.001f;
                    pawn.health.AddHediff(shadow);
                    Log.Message($"[SuperColonyBuffs] Psionic: Applied Shadow_III to {pawn.Label}");
                }
            }
            catch (System.Exception ex)
            {
                Log.Error($"[SuperColonyBuffs] Psionic: Failed to apply base buffs. Error: {ex.Message}");
            }
        }

        private static void ApplyAllPsionicAbilities(Pawn pawn)
        {
            if (pawn.abilities != null)
            {
                try
                {
                    AbilityDef[] psionicAbilities = new[]
                    {
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicBlast", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicBlast_I", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicBlast_II", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicBlast_III", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicBarrier", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicBarrier_Projected", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicDash", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicDash_I", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicDash_II", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicDash_III", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicAugment", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicAugment_I", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicAugment_II", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicAugment_III", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicShock", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicShock_I", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicShock_II", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicShock_III", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicStorm", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicSeer", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicSeer_I", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicSeer_II", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicSeer_III", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicOverdrive", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicOverdrive_I", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicOverdrive_II", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_PsionicOverdrive_III", false)
                    };

                    foreach (var abilityDef in psionicAbilities)
                    {
                        if (abilityDef != null && !pawn.abilities.abilities.Any(a => a.def == abilityDef))
                        {
                            pawn.abilities.GainAbility(abilityDef);
                            Log.Message($"[SuperColonyBuffs] Psionic: Granted {abilityDef.defName} to {pawn.Label}");
                        }
                    }
                }
                catch (System.Exception ex)
                {
                    Log.Error($"[SuperColonyBuffs] Psionic: Failed to apply Psionic abilities. Error: {ex.Message}");
                }
            }
        }

        private static void ApplyAllShadowAbilities(Pawn pawn)
        {
            if (pawn.abilities != null)
            {
                try
                {
                    AbilityDef[] shadowAbilities = new[]
                    {
                        DefDatabase<AbilityDef>.GetNamed("TM_ShadowBolt", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_ShadowBolt_I", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_ShadowBolt_II", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_ShadowBolt_III", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_ShadowStep", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_ShadowStep_I", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_ShadowStep_II", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_ShadowStep_III", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_ShadowStrike", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_VeilOfShadows", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_ShadowCall", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_ShadowCall_I", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_ShadowCall_II", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_ShadowCall_III", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_ShadowHound", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_ShadowHound_I", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_ShadowHound_II", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_ShadowHound_III", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_EtherealBlade", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_EtherealBlade_I", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_EtherealBlade_II", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_EtherealBlade_III", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_ShadowClone", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_ShadowClone_I", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_ShadowClone_II", false),
                        DefDatabase<AbilityDef>.GetNamed("TM_ShadowClone_III", false)
                    };

                    foreach (var abilityDef in shadowAbilities)
                    {
                        if (abilityDef != null && !pawn.abilities.abilities.Any(a => a.def == abilityDef))
                        {
                            pawn.abilities.GainAbility(abilityDef);
                            Log.Message($"[SuperColonyBuffs] Shadow: Granted {abilityDef.defName} to {pawn.Label}");
                        }
                    }
                }
                catch (System.Exception ex)
                {
                    Log.Error($"[SuperColonyBuffs] Shadow: Failed to apply Shadow abilities. Error: {ex.Message}");
                }
            }
        }

        private static void ApplyNecroBuffs(Pawn pawn)
        {
            try
            {
                HediffDef undeadDef = DefDatabase<HediffDef>.GetNamed("TM_UndeadHD", false);
                if (undeadDef != null)
                {
                    Hediff undead = HediffMaker.MakeHediff(undeadDef, pawn);
                    undead.Severity = 0.95f;
                    pawn.health.AddHediff(undead);
                    Log.Message($"[SuperColonyBuffs] Necro: Applied TM_UndeadHD to {pawn.Label}");
                }

                HediffDef lichDef = DefDatabase<HediffDef>.GetNamed("TM_LichHD", false);
                if (lichDef != null)
                {
                    Hediff lich = HediffMaker.MakeHediff(lichDef, pawn);
                    lich.Severity = 0.95f;
                    pawn.health.AddHediff(lich);
                    Log.Message($"[SuperColonyBuffs] Necro: Applied TM_LichHD to {pawn.Label}");
                }

                HediffDef undeadStageDef = DefDatabase<HediffDef>.GetNamed("TM_UndeadStageHD", false);
                if (undeadStageDef != null)
                {
                    Hediff undeadStage = HediffMaker.MakeHediff(undeadStageDef, pawn);
                    undeadStage.Severity = 0.001f;
                    pawn.health.AddHediff(undeadStage);
                    Log.Message($"[SuperColonyBuffs] Necro: Applied TM_UndeadStageHD to {pawn.Label}");
                }
            }
            catch (System.Exception ex)
            {
                Log.Error($"[SuperColonyBuffs] Necro: Failed to apply Necro buffs. Error: {ex.Message}");
            }
        }

        private static void ApplyArcaneBuffs(Pawn pawn)
        {
            try
            {
                HediffDef movementDef = DefDatabase<HediffDef>.GetNamed("TM_Movement", false);
                if (movementDef != null)
                {
                    Hediff movement = HediffMaker.MakeHediff(movementDef, pawn);
                    movement.Severity = 1f;
                    pawn.health.AddHediff(movement);
                    Log.Message($"[SuperColonyBuffs] Arcane: Applied TM_Movement to {pawn.Label}");
                }

                HediffDef manipulationDef = DefDatabase<HediffDef>.GetNamed("TM_Manipulation", false);
                if (manipulationDef != null)
                {
                    Hediff manipulation = HediffMaker.MakeHediff(manipulationDef, pawn);
                    manipulation.Severity = 1f;
                    pawn.health.AddHediff(manipulation);
                    Log.Message($"[SuperColonyBuffs] Arcane: Applied TM_Manipulation to {pawn.Label}");
                }

                HediffDef breathingDef = DefDatabase<HediffDef>.GetNamed("TM_Breathing", false);
                if (breathingDef != null)
                {
                    Hediff breathing = HediffMaker.MakeHediff(breathingDef, pawn);
                    breathing.Severity = 1f;
                    pawn.health.AddHediff(breathing);
                    Log.Message($"[SuperColonyBuffs] Arcane: Applied TM_Breathing to {pawn.Label}");
                }

                HediffDef sightDef = DefDatabase<HediffDef>.GetNamed("TM_Sight", false);
                if (sightDef != null)
                {
                    Hediff sight = HediffMaker.MakeHediff(sightDef, pawn);
                    sight.Severity = 1f;
                    pawn.health.AddHediff(sight);
                    Log.Message($"[SuperColonyBuffs] Arcane: Applied TM_Sight to {pawn.Label}");
                }
            }
            catch (System.Exception ex)
            {
                Log.Error($"[SuperColonyBuffs] Arcane: Failed to apply Arcane buffs. Error: {ex.Message}");
            }
        }

        private static void ApplyAllNecromancerAbilities(Pawn pawn)
        {
            if (pawn.abilities != null)
            {
                try
                {
                    AbilityDef raiseUndeadDef = DefDatabase<AbilityDef>.GetNamed("TM_RaiseUndead", false);
                    if (raiseUndeadDef != null && !pawn.abilities.abilities.Any(a => a.def == raiseUndeadDef))
                    {
                        pawn.abilities.GainAbility(raiseUndeadDef);
                        Log.Message($"[SuperColonyBuffs] Necromancer: Granted TM_RaiseUndead to {pawn.Label}");
                    }

                    AbilityDef dismissUndeadDef = DefDatabase<AbilityDef>.GetNamed("TM_DismissUndead", false);
                    if (dismissUndeadDef != null && !pawn.abilities.abilities.Any(a => a.def == dismissUndeadDef))
                    {
                        pawn.abilities.GainAbility(dismissUndeadDef);
                        Log.Message($"[SuperColonyBuffs] Necromancer: Granted TM_DismissUndead to {pawn.Label}");
                    }

                    AbilityDef deathMarkDef = DefDatabase<AbilityDef>.GetNamed("TM_DeathMark_III", false);
                    if (deathMarkDef != null && !pawn.abilities.abilities.Any(a => a.def == deathMarkDef))
                    {
                        pawn.abilities.GainAbility(deathMarkDef);
                        Log.Message($"[SuperColonyBuffs] Necromancer: Granted TM_DeathMark_III to {pawn.Label}");
                    }

                    AbilityDef fogOfTormentDef = DefDatabase<AbilityDef>.GetNamed("TM_FogOfTorment", false);
                    if (fogOfTormentDef != null && !pawn.abilities.abilities.Any(a => a.def == fogOfTormentDef))
                    {
                        pawn.abilities.GainAbility(fogOfTormentDef);
                        Log.Message($"[SuperColonyBuffs] Necromancer: Granted TM_FogOfTorment to {pawn.Label}");
                    }

                    AbilityDef consumeCorpseDef = DefDatabase<AbilityDef>.GetNamed("TM_ConsumeCorpse_III", false);
                    if (consumeCorpseDef != null && !pawn.abilities.abilities.Any(a => a.def == consumeCorpseDef))
                    {
                        pawn.abilities.GainAbility(consumeCorpseDef);
                        Log.Message($"[SuperColonyBuffs] Necromancer: Granted TM_ConsumeCorpse_III to {pawn.Label}");
                    }

                    AbilityDef consumeCorpseMassDef = DefDatabase<AbilityDef>.GetNamed("TM_ConsumeCorpse_Mass", false);
                    if (consumeCorpseMassDef != null && !pawn.abilities.abilities.Any(a => a.def == consumeCorpseMassDef))
                    {
                        pawn.abilities.GainAbility(consumeCorpseMassDef);
                        Log.Message($"[SuperColonyBuffs] Necromancer: Granted TM_ConsumeCorpse_Mass to {pawn.Label}");
                    }

                    AbilityDef corpseExplosionDef = DefDatabase<AbilityDef>.GetNamed("TM_CorpseExplosion_III", false);
                    if (corpseExplosionDef != null && !pawn.abilities.abilities.Any(a => a.def == corpseExplosionDef))
                    {
                        pawn.abilities.GainAbility(corpseExplosionDef);
                        Log.Message($"[SuperColonyBuffs] Necromancer: Granted TM_CorpseExplosion_III to {pawn.Label}");
                    }

                    AbilityDef lichFormDef = DefDatabase<AbilityDef>.GetNamed("TM_LichForm", false);
                    if (lichFormDef != null && !pawn.abilities.abilities.Any(a => a.def == lichFormDef))
                    {
                        pawn.abilities.GainAbility(lichFormDef);
                        Log.Message($"[SuperColonyBuffs] Necromancer: Granted TM_LichForm to {pawn.Label}");
                    }

                    AbilityDef deathBoltDef = DefDatabase<AbilityDef>.GetNamed("TM_DeathBolt_III", false);
                    if (deathBoltDef != null && !pawn.abilities.abilities.Any(a => a.def == deathBoltDef))
                    {
                        pawn.abilities.GainAbility(deathBoltDef);
                        Log.Message($"[SuperColonyBuffs] Necromancer: Granted TM_DeathBolt_III to {pawn.Label}");
                    }
                }
                catch (System.Exception ex)
                {
                    Log.Error($"[SuperColonyBuffs] Necromancer: Failed to apply abilities. Error: {ex.Message}");
                }
            }
        }

        private static void ApplyAllLightningMageAbilities(Pawn pawn)
        {
            if (pawn.abilities != null)
            {
                try
                {
                    AbilityDef ampDef = DefDatabase<AbilityDef>.GetNamed("TM_AMP_III", false);
                    if (ampDef != null && !pawn.abilities.abilities.Any(a => a.def == ampDef))
                    {
                        pawn.abilities.GainAbility(ampDef);
                        Log.Message($"[SuperColonyBuffs] LightningMage: Granted TM_AMP_III to {pawn.Label}");
                    }

                    AbilityDef lightningCloudDef = DefDatabase<AbilityDef>.GetNamed("TM_LightningCloud", false);
                    if (lightningCloudDef != null && !pawn.abilities.abilities.Any(a => a.def == lightningCloudDef))
                    {
                        pawn.abilities.GainAbility(lightningCloudDef);
                        Log.Message($"[SuperColonyBuffs] LightningMage: Granted TM_LightningCloud to {pawn.Label}");
                    }

                    AbilityDef lightningBoltDef = DefDatabase<AbilityDef>.GetNamed("TM_LightningBolt", false);
                    if (lightningBoltDef != null && !pawn.abilities.abilities.Any(a => a.def == lightningBoltDef))
                    {
                        pawn.abilities.GainAbility(lightningBoltDef);
                        Log.Message($"[SuperColonyBuffs] LightningMage: Granted TM_LightningBolt to {pawn.Label}");
                    }

                    AbilityDef lightningStormDef = DefDatabase<AbilityDef>.GetNamed("TM_LightningStorm", false);
                    if (lightningStormDef != null && !pawn.abilities.abilities.Any(a => a.def == lightningStormDef))
                    {
                        pawn.abilities.GainAbility(lightningStormDef);
                        Log.Message($"[SuperColonyBuffs] LightningMage: Granted TM_LightningStorm to {pawn.Label}");
                    }

                    AbilityDef eyeOfTheStormDef = DefDatabase<AbilityDef>.GetNamed("TM_EyeOfTheStorm", false);
                    if (eyeOfTheStormDef != null && !pawn.abilities.abilities.Any(a => a.def == eyeOfTheStormDef))
                    {
                        pawn.abilities.GainAbility(eyeOfTheStormDef);
                        Log.Message($"[SuperColonyBuffs] LightningMage: Granted TM_EyeOfTheStorm to {pawn.Label}");
                    }
                }
                catch (System.Exception ex)
                {
                    Log.Error($"[SuperColonyBuffs] LightningMage: Failed to apply abilities. Error: {ex.Message}");
                }
            }
        }

        private static void ApplyAllBladedancerAbilities(Pawn pawn)
        {
            if (pawn.abilities != null)
            {
                try
                {
                    AbilityDef bladeFocusDef = DefDatabase<AbilityDef>.GetNamed("TM_BladeFocus", false);
                    if (bladeFocusDef != null && !pawn.abilities.abilities.Any(a => a.def == bladeFocusDef))
                    {
                        pawn.abilities.GainAbility(bladeFocusDef);
                        Log.Message($"[SuperColonyBuffs] Bladedancer: Granted TM_BladeFocus to {pawn.Label}");
                    }

                    AbilityDef bladeArtDef = DefDatabase<AbilityDef>.GetNamed("TM_BladeArt", false);
                    if (bladeArtDef != null && !pawn.abilities.abilities.Any(a => a.def == bladeArtDef))
                    {
                        pawn.abilities.GainAbility(bladeArtDef);
                        Log.Message($"[SuperColonyBuffs] Bladedancer: Granted TM_BladeArt to {pawn.Label}");
                    }

                    AbilityDef bladeSpinDef = DefDatabase<AbilityDef>.GetNamed("TM_BladeSpin", false);
                    if (bladeSpinDef != null && !pawn.abilities.abilities.Any(a => a.def == bladeSpinDef))
                    {
                        pawn.abilities.GainAbility(bladeSpinDef);
                        Log.Message($"[SuperColonyBuffs] Bladedancer: Granted TM_BladeSpin to {pawn.Label}");
                    }

                    AbilityDef seismicSlashDef = DefDatabase<AbilityDef>.GetNamed("TM_SeismicSlash", false);
                    if (seismicSlashDef != null && !pawn.abilities.abilities.Any(a => a.def == seismicSlashDef))
                    {
                        pawn.abilities.GainAbility(seismicSlashDef);
                        Log.Message($"[SuperColonyBuffs] Bladedancer: Granted TM_SeismicSlash to {pawn.Label}");
                    }

                    AbilityDef phaseStrikeDef = DefDatabase<AbilityDef>.GetNamed("TM_PhaseStrike_III", false);
                    if (phaseStrikeDef != null && !pawn.abilities.abilities.Any(a => a.def == phaseStrikeDef))
                    {
                        pawn.abilities.GainAbility(phaseStrikeDef);
                        Log.Message($"[SuperColonyBuffs] Bladedancer: Granted TM_PhaseStrike_III to {pawn.Label}");
                    }
                }
                catch (System.Exception ex)
                {
                    Log.Error($"[SuperColonyBuffs] Bladedancer: Failed to apply abilities. Error: {ex.Message}");
                }
            }
        }

        private static void ApplyTMGiftedTrait(Pawn pawn)
        {
            if (pawn != null && pawn.story != null)
            {
                try
                {
                    TraitDef tmGiftedTrait = DefDatabase<TraitDef>.GetNamed("TM_Gifted", false);
                    if (tmGiftedTrait != null)
                    {
                        // Remove conflicting traits to avoid issues
                        List<Trait> traitsToRemove = new List<Trait>();
                        foreach (Trait trait in pawn.story.traits.allTraits)
                        {
                            if (trait.def.conflictingTraits != null && trait.def.conflictingTraits.Contains(tmGiftedTrait))
                            {
                                traitsToRemove.Add(trait);
                            }
                        }
                        foreach (Trait trait in traitsToRemove)
                        {
                            pawn.story.traits.RemoveTrait(trait);
                        }

                        // Add TM_Gifted trait
                        if (!pawn.story.traits.HasTrait(tmGiftedTrait))
                        {
                            pawn.story.traits.GainTrait(new Trait(tmGiftedTrait));
                            Log.Message($"[SuperColonyBuffs] Applied TM_Gifted trait to {pawn.Label}");
                        }
                    }
                }
                catch (System.Exception ex)
                {
                    Log.Error($"[SuperColonyBuffs] Failed to apply TM_Gifted trait to {pawn.Label}. Error: {ex.Message}");
                }
            }
        }
    }
}