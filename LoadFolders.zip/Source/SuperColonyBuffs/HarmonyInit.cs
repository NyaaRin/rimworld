using HarmonyLib;
using CombatExtended;
using Verse;

namespace SuperColonyBuffs
{
    [StaticConstructorOnStartup]
    public static class HarmonyInit
    {
        static HarmonyInit()
        {
            Harmony harmony = new Harmony("YourName.SuperColonyBuffs");
            harmony.PatchAll();
        }
    }
}